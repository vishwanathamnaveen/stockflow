"""Shared building blocks for StockFlow services."""
