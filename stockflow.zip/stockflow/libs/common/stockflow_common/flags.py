"""File-based feature flags (config/flags.json). Re-read on every call so flags
can be flipped while services are running, like a tiny flagd."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .settings import CONFIG_DIR


def _flags_path() -> Path:
    return Path(os.environ.get("STOCKFLOW_FLAGS_PATH", CONFIG_DIR / "flags.json"))


def _load() -> dict[str, Any]:
    try:
        with open(_flags_path(), encoding="utf-8") as fh:
            return json.load(fh).get("flags", {})
    except FileNotFoundError:
        return {}


def is_enabled(name: str, default: bool = False) -> bool:
    flag = _load().get(name)
    return bool(flag.get("enabled", default)) if flag else default


def flag_value(name: str, default: Any = None) -> Any:
    """Return the flag's value if the flag is enabled, else ``default``."""
    flag = _load().get(name)
    if not flag or not flag.get("enabled"):
        return default
    return flag.get("value", default)


def all_flags() -> dict[str, Any]:
    return _load()
