"""Service registry and per-service settings, loaded from config/services.yaml."""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import yaml

ROOT = Path(os.environ.get("STOCKFLOW_ROOT", Path(__file__).resolve().parents[3]))
CONFIG_DIR = ROOT / "config"
VAR_DIR = Path(os.environ.get("STOCKFLOW_VAR_DIR", ROOT / "var"))


def _env_key(service: str) -> str:
    return service.upper().replace("-", "_")


@lru_cache
def load_registry() -> dict:
    with open(CONFIG_DIR / "services.yaml", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def service_port(service: str) -> int:
    return int(load_registry()["services"][service]["port"])


def service_url(service: str) -> str:
    override = os.environ.get(f"{_env_key(service)}_URL")
    if override:
        return override.rstrip("/")
    registry = load_registry()
    return f"http://{registry.get('host', '127.0.0.1')}:{service_port(service)}"


def port_to_service() -> dict[int, str]:
    return {int(cfg["port"]): name for name, cfg in load_registry()["services"].items()}


@dataclass(frozen=True)
class ServiceSettings:
    name: str
    port: int
    database_url: str

    @classmethod
    def for_service(cls, name: str) -> "ServiceSettings":
        db_url = os.environ.get(f"{_env_key(name)}_DATABASE_URL")
        if not db_url:
            data_dir = VAR_DIR / "data"
            data_dir.mkdir(parents=True, exist_ok=True)
            db_url = f"sqlite:///{(data_dir / f'{name}.db').as_posix()}"
        return cls(name=name, port=service_port(name), database_url=db_url)


def env_int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


def env_float(name: str, default: float) -> float:
    return float(os.environ.get(name, default))


def env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}
