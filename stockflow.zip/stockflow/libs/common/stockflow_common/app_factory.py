"""Standard FastAPI app for every StockFlow service: health, error mapping,
logging and tracing."""
from __future__ import annotations

from collections.abc import Callable, Iterable
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .errors import DomainError
from .flags import all_flags
from .logging_setup import configure_logging
from .tracing import setup_tracing


def create_service_app(
    name: str,
    *,
    description: str,
    version: str = "1.0.0",
    on_startup: Iterable[Callable[[], None]] = (),
    on_shutdown: Iterable[Callable[[], None]] = (),
) -> FastAPI:
    startup_hooks = list(on_startup)
    shutdown_hooks = list(on_shutdown)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        for hook in startup_hooks:
            hook()
        yield
        for hook in shutdown_hooks:
            hook()

    configure_logging(name)
    app = FastAPI(title=f"StockFlow {name}", description=description, version=version, lifespan=lifespan)

    @app.exception_handler(DomainError)
    async def _domain_error(_request: Request, exc: DomainError) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": exc.code, "message": exc.message, "details": exc.details},
        )

    @app.get("/health", tags=["ops"])
    def health() -> dict:
        return {"service": name, "status": "ok"}

    @app.get("/flags", tags=["ops"])
    def flags() -> dict:
        return all_flags()

    setup_tracing(name, app)
    return app
