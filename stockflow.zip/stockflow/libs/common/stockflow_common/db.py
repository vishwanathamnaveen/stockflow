"""SQLite database helper. One database file per service (see ADR-001)."""
from __future__ import annotations

from collections.abc import Iterator

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker


class Database:
    def __init__(self, url: str) -> None:
        connect_args = {"check_same_thread": False, "timeout": 15} if url.startswith("sqlite") else {}
        self.engine = create_engine(url, connect_args=connect_args)
        if url.startswith("sqlite"):
            @event.listens_for(self.engine, "connect")
            def _sqlite_pragmas(dbapi_conn, _record):  # pragma: no cover - driver hook
                cursor = dbapi_conn.cursor()
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.close()
        self.SessionLocal = sessionmaker(bind=self.engine, expire_on_commit=False)

    def create_all(self, base: type[DeclarativeBase]) -> None:
        base.metadata.create_all(self.engine)

    def reset(self, base: type[DeclarativeBase]) -> None:
        base.metadata.drop_all(self.engine)
        base.metadata.create_all(self.engine)

    def session(self) -> Iterator[Session]:
        """FastAPI dependency: one session per request."""
        with self.SessionLocal() as session:
            yield session
