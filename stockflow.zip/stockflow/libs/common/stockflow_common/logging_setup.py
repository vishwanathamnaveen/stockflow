"""Logging with service name and trace id on every line (feeds the runtime/log graph)."""
from __future__ import annotations

import logging
import sys

from opentelemetry import trace


class _TraceContextFilter(logging.Filter):
    def __init__(self, service: str) -> None:
        super().__init__()
        self.service = service

    def filter(self, record: logging.LogRecord) -> bool:
        ctx = trace.get_current_span().get_span_context()
        record.service = self.service
        record.trace_id = format(ctx.trace_id, "032x") if ctx.is_valid else "-"
        return True


def configure_logging(service: str, level: int = logging.INFO) -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.addFilter(_TraceContextFilter(service))
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s service=%(service)s trace=%(trace_id)s %(name)s: %(message)s")
    )
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level)
