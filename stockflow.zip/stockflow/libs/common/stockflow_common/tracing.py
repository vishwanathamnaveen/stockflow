"""OpenTelemetry tracing that writes spans to var/traces/<service>.jsonl.

No collector or Jaeger needed: each service appends one JSON object per span.
The runtime graph is built from these files. Set STOCKFLOW_TRACING=0 to disable.
"""
from __future__ import annotations

import json
import threading
from collections.abc import Sequence
from pathlib import Path

from fastapi import FastAPI
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import ReadableSpan, TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter, SpanExportResult

from .settings import VAR_DIR, env_bool, port_to_service

_lock = threading.Lock()
_configured = False


class JsonlSpanExporter(SpanExporter):
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        lines = []
        for span in spans:
            ctx = span.get_span_context()
            lines.append(
                json.dumps(
                    {
                        "trace_id": format(ctx.trace_id, "032x"),
                        "span_id": format(ctx.span_id, "016x"),
                        "parent_span_id": format(span.parent.span_id, "016x") if span.parent else None,
                        "name": span.name,
                        "kind": span.kind.name,
                        "service": span.resource.attributes.get("service.name"),
                        "start_unix_nano": span.start_time,
                        "duration_ms": round((span.end_time - span.start_time) / 1e6, 3),
                        "status": span.status.status_code.name,
                        "attributes": dict(span.attributes or {}),
                    },
                    default=str,
                )
            )
        with self._lock, open(self.path, "a", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        return SpanExportResult.SUCCESS

    def shutdown(self) -> None:
        return None


def _httpx_request_hook(span, request) -> None:
    """Tag outgoing calls with the target service name (peer.service)."""
    try:
        port = request.url.port if hasattr(request, "url") else request[1].port
        target = port_to_service().get(port)
        if target and span.is_recording():
            span.set_attribute("peer.service", target)
    except Exception:  # pragma: no cover - never break a request because of tracing
        pass


def tracing_enabled() -> bool:
    return env_bool("STOCKFLOW_TRACING", True)


def setup_tracing(service_name: str, app: FastAPI) -> None:
    global _configured
    if not tracing_enabled():
        return
    with _lock:
        if not _configured:
            provider = TracerProvider(resource=Resource.create({"service.name": service_name}))
            provider.add_span_processor(
                BatchSpanProcessor(JsonlSpanExporter(VAR_DIR / "traces" / f"{service_name}.jsonl"))
            )
            trace.set_tracer_provider(provider)
            HTTPXClientInstrumentor().instrument(request_hook=_httpx_request_hook)
            _configured = True
    FastAPIInstrumentor.instrument_app(app, excluded_urls="health", exclude_spans=["receive", "send"])


def get_tracer(name: str = "stockflow"):
    return trace.get_tracer(name)
