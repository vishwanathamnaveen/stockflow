"""Transactional outbox (publisher side) and idempotent inbox (consumer side).

Publisher: `publish_event()` writes the event into the service's own `outbox`
table in the same DB transaction as the business change. `OutboxRelay` (a
background thread) forwards pending rows to the event bus over HTTP.

Consumer: `build_event_router()` exposes POST /events/receive. The event bus
delivers there. Each event id is recorded in the `inbox` table so redelivered
events are processed once.

Trace context travels in the event headers, so a trace spans producer ->
event bus -> consumer. See ADR-002.
"""
from __future__ import annotations

import json
import logging
import threading
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

import httpx
from fastapi import APIRouter, Depends, HTTPException
from opentelemetry import context as otel_context
from opentelemetry import propagate
from opentelemetry.trace import SpanKind
from pydantic import BaseModel
from sqlalchemy import DateTime, Integer, String, Text, select
from sqlalchemy.orm import Mapped, Session, mapped_column

from .settings import env_bool, service_url
from .tracing import get_tracer

log = logging.getLogger(__name__)
tracer = get_tracer("stockflow.events")


def utcnow() -> datetime:
    return datetime.now(UTC)


class OutboxMixin:
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    event_id: Mapped[str] = mapped_column(String(36), unique=True, index=True)
    topic: Mapped[str] = mapped_column(String(100), index=True)
    payload: Mapped[str] = mapped_column(Text)
    headers: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)


class InboxMixin:
    event_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    topic: Mapped[str] = mapped_column(String(100))
    processed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


def publish_event(session: Session, outbox_model: type, *, topic: str, payload: dict, source: str) -> str:
    """Stage an event in the outbox. Caller commits the session."""
    event_id = str(uuid.uuid4())
    headers: dict[str, str] = {"source": source}
    with tracer.start_as_current_span(
        f"{topic} publish",
        kind=SpanKind.PRODUCER,
        attributes={
            "messaging.system": "stockflow-event-bus",
            "messaging.destination.name": topic,
            "messaging.operation.type": "publish",
            "messaging.message.id": event_id,
        },
    ):
        propagate.inject(headers)
    session.add(
        outbox_model(
            event_id=event_id,
            topic=topic,
            payload=json.dumps(payload, default=str),
            headers=json.dumps(headers),
        )
    )
    return event_id


class OutboxRelay:
    """Background thread that forwards outbox rows to the event bus."""

    def __init__(
        self,
        session_factory: Callable[[], Session],
        outbox_model: type,
        *,
        source: str,
        interval_seconds: float = 0.5,
        batch_size: int = 50,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.session_factory = session_factory
        self.outbox_model = outbox_model
        self.source = source
        self.interval_seconds = interval_seconds
        self.batch_size = batch_size
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._client = http_client or httpx.Client(timeout=5.0)

    def start(self) -> None:
        if not env_bool("STOCKFLOW_RELAY", True):
            return
        self._thread = threading.Thread(target=self._run, name=f"{self.source}-outbox-relay", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self.flush()
            except Exception:  # pragma: no cover - keep relay alive
                log.exception("outbox relay iteration failed")
            self._stop.wait(self.interval_seconds)

    def flush(self) -> int:
        sent = 0
        with self.session_factory() as session:
            rows = session.scalars(
                select(self.outbox_model)
                .where(self.outbox_model.published_at.is_(None))
                .order_by(self.outbox_model.id)
                .limit(self.batch_size)
            ).all()
            for row in rows:
                headers = json.loads(row.headers or "{}")
                token = otel_context.attach(propagate.extract(headers))
                try:
                    response = self._client.post(
                        f"{service_url('event-bus')}/publish",
                        json={
                            "event_id": row.event_id,
                            "topic": row.topic,
                            "source": self.source,
                            "payload": json.loads(row.payload),
                            "headers": headers,
                        },
                    )
                    response.raise_for_status()
                    row.published_at = utcnow()
                    sent += 1
                except Exception as exc:
                    row.attempts += 1
                    row.last_error = str(exc)[:500]
                    log.warning("outbox publish failed for %s (%s): %s", row.event_id, row.topic, exc)
                    break  # keep ordering; retry on next tick
                finally:
                    otel_context.detach(token)
            session.commit()
        return sent


class EventEnvelope(BaseModel):
    event_id: str
    topic: str
    source: str
    payload: dict[str, Any]
    published_at: datetime | None = None


EventHandler = Callable[[Session, dict[str, Any]], None]


def build_event_router(
    *,
    handlers: dict[str, EventHandler],
    session_dependency: Callable,
    inbox_model: type,
) -> APIRouter:
    router = APIRouter(tags=["events"])

    @router.post("/events/receive")
    def receive_event(envelope: EventEnvelope, session: Session = Depends(session_dependency)) -> dict:
        handler = handlers.get(envelope.topic)
        if handler is None:
            raise HTTPException(status_code=400, detail=f"no handler for topic {envelope.topic}")
        if session.get(inbox_model, envelope.event_id) is not None:
            return {"status": "duplicate", "event_id": envelope.event_id}
        with tracer.start_as_current_span(
            f"{envelope.topic} process",
            kind=SpanKind.CONSUMER,
            attributes={
                "messaging.system": "stockflow-event-bus",
                "messaging.destination.name": envelope.topic,
                "messaging.operation.type": "process",
                "messaging.message.id": envelope.event_id,
                "messaging.source": envelope.source,
            },
        ):
            handler(session, envelope.payload)
            session.add(inbox_model(event_id=envelope.event_id, topic=envelope.topic))
            session.commit()
        return {"status": "processed", "event_id": envelope.event_id}

    @router.get("/events/handlers")
    def list_handlers() -> dict:
        return {"topics": sorted(handlers)}

    return router
