"""HTTP client for service-to-service REST calls, with timeout and retry policy.

Retries apply only to timeouts, connection errors and 5xx responses.
4xx responses are returned to the caller unchanged (they are business answers).
"""
from __future__ import annotations

import logging
import time
from typing import Any

import httpx

from .errors import DownstreamUnavailable
from .settings import service_url

log = logging.getLogger(__name__)


class _RetryableStatus(Exception):
    def __init__(self, response: httpx.Response) -> None:
        super().__init__(f"HTTP {response.status_code}")
        self.response = response


class ServiceClient:
    def __init__(
        self,
        service: str,
        *,
        timeout: float = 5.0,
        max_retries: int = 0,
        backoff_seconds: float = 0.2,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.service = service
        self.max_retries = max_retries
        self.backoff_seconds = backoff_seconds
        self._client = httpx.Client(base_url=service_url(service), timeout=timeout, transport=transport)

    def request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        attempt = 0
        while True:
            try:
                response = self._client.request(method, path, **kwargs)
                if response.status_code >= 500:
                    raise _RetryableStatus(response)
                return response
            except (httpx.TimeoutException, httpx.TransportError, _RetryableStatus) as exc:
                if attempt >= self.max_retries:
                    raise DownstreamUnavailable(self.service, f"{exc.__class__.__name__}: {exc}") from exc
                attempt += 1
                log.warning(
                    "retrying %s %s on %s (attempt %d/%d): %s",
                    method, path, self.service, attempt, self.max_retries, exc,
                )
                time.sleep(self.backoff_seconds * attempt)

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("POST", path, **kwargs)

    def close(self) -> None:
        self._client.close()
