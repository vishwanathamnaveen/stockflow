"""Test helpers: isolate each service's tests from real data, flags and tracing.

Call `prepare_test_environment(<service>)` at the top of a service's conftest,
before importing the service package.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path

from .settings import CONFIG_DIR, _env_key

_FLAGS_ENV = "STOCKFLOW_FLAGS_PATH"


def prepare_test_environment(service: str) -> Path:
    tmp = Path(tempfile.mkdtemp(prefix=f"stockflow-{service}-"))
    os.environ["STOCKFLOW_TRACING"] = "0"
    os.environ["STOCKFLOW_RELAY"] = "0"
    os.environ[f"{_env_key(service)}_DATABASE_URL"] = f"sqlite:///{(tmp / 'test.db').as_posix()}"
    flags_path = tmp / "flags.json"
    shutil.copy(CONFIG_DIR / "flags.json", flags_path)
    os.environ[_FLAGS_ENV] = str(flags_path)
    return tmp


def set_flag(name: str, enabled: bool, value=None) -> None:
    path = Path(os.environ[_FLAGS_ENV])
    data = json.loads(path.read_text())
    flag = data["flags"].setdefault(name, {})
    flag["enabled"] = enabled
    if value is not None:
        flag["value"] = value
    path.write_text(json.dumps(data, indent=2))


def reset_flags() -> None:
    shutil.copy(CONFIG_DIR / "flags.json", Path(os.environ[_FLAGS_ENV]))
