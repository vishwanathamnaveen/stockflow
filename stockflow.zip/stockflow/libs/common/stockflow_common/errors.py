"""Domain errors mapped to HTTP responses by the app factory."""
from __future__ import annotations


class DomainError(Exception):
    status_code = 400
    code = "domain_error"

    def __init__(self, message: str, *, details: dict | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}


class NotFound(DomainError):
    status_code = 404
    code = "not_found"


class Conflict(DomainError):
    status_code = 409
    code = "conflict"


class ValidationFailed(DomainError):
    status_code = 422
    code = "validation_failed"


class DownstreamUnavailable(DomainError):
    """A dependency timed out, refused the connection or kept returning 5xx."""

    status_code = 503
    code = "downstream_unavailable"

    def __init__(self, service: str, reason: str) -> None:
        super().__init__(f"{service} unavailable: {reason}", details={"service": service})
        self.service = service
