import httpx
import pytest

from stockflow_common.errors import DownstreamUnavailable
from stockflow_common.http_client import ServiceClient


def _client(handler, retries):
    return ServiceClient("inventory", max_retries=retries, backoff_seconds=0, transport=httpx.MockTransport(handler))


def test_retries_on_5xx_then_succeeds():
    calls = []

    def handler(request):
        calls.append(request)
        return httpx.Response(503) if len(calls) < 3 else httpx.Response(200, json={"ok": True})

    response = _client(handler, retries=2).get("/stock/X")
    assert response.status_code == 200
    assert len(calls) == 3


def test_does_not_retry_4xx():
    calls = []

    def handler(request):
        calls.append(request)
        return httpx.Response(409, json={"error": "conflict"})

    assert _client(handler, retries=3).post("/reservations").status_code == 409
    assert len(calls) == 1


def test_raises_downstream_unavailable_when_retries_exhausted():
    def handler(request):
        raise httpx.ReadTimeout("slow", request=request)

    with pytest.raises(DownstreamUnavailable) as exc:
        _client(handler, retries=1).get("/stock/X")
    assert exc.value.service == "inventory"
