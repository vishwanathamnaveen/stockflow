import json

import httpx
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from stockflow_common.events import OutboxMixin, OutboxRelay, publish_event


class Base(DeclarativeBase):
    pass


class Outbox(OutboxMixin, Base):
    __tablename__ = "outbox"


def _session_factory():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, expire_on_commit=False)


def test_publish_event_stages_row_in_outbox():
    Session = _session_factory()
    with Session() as session:
        event_id = publish_event(session, Outbox, topic="stock.low", payload={"sku": "A"}, source="inventory")
        session.commit()
        row = session.query(Outbox).one()
    assert row.event_id == event_id
    assert json.loads(row.payload) == {"sku": "A"}
    assert row.published_at is None


def test_relay_forwards_rows_and_marks_them_published():
    Session = _session_factory()
    sent = []

    def handler(request):
        sent.append(json.loads(request.content))
        return httpx.Response(202, json={})

    with Session() as session:
        publish_event(session, Outbox, topic="order.confirmed", payload={"order_number": "SO-1"}, source="sales-order")
        session.commit()
    relay = OutboxRelay(Session, Outbox, source="sales-order", http_client=httpx.Client(transport=httpx.MockTransport(handler)))
    assert relay.flush() == 1
    assert sent[0]["topic"] == "order.confirmed"
    with Session() as session:
        assert session.query(Outbox).one().published_at is not None


def test_relay_keeps_row_pending_when_bus_is_down():
    Session = _session_factory()

    def handler(request):
        raise httpx.ConnectError("refused", request=request)

    with Session() as session:
        publish_event(session, Outbox, topic="stock.low", payload={}, source="inventory")
        session.commit()
    relay = OutboxRelay(Session, Outbox, source="inventory", http_client=httpx.Client(transport=httpx.MockTransport(handler)))
    assert relay.flush() == 0
    with Session() as session:
        row = session.query(Outbox).one()
        assert row.published_at is None and row.attempts == 1
