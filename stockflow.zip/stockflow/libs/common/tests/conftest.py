import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from stockflow_common.testing import prepare_test_environment  # noqa: E402

prepare_test_environment("common")
