from stockflow_common.flags import flag_value, is_enabled
from stockflow_common.testing import reset_flags, set_flag


def test_flag_toggles_are_read_live():
    reset_flags()
    assert is_enabled("auto_reorder") is True
    set_flag("auto_reorder", False)
    assert is_enabled("auto_reorder") is False
    reset_flags()


def test_flag_value_only_when_enabled():
    reset_flags()
    assert flag_value("inventory_reservation_delay_ms", 0) == 0
    set_flag("inventory_reservation_delay_ms", True, 50)
    assert flag_value("inventory_reservation_delay_ms", 0) == 50
    reset_flags()


def test_unknown_flag_uses_default():
    assert is_enabled("does_not_exist", default=True) is True
