"""End-to-end: order -> reservation -> stock.low -> auto reorder -> receipt.

Needs the full system: python scripts/run_local.py --reset && python scripts/seed_data.py
Run: python -m pytest tests/e2e -m e2e
"""
import time

import httpx
import pytest

GATEWAY = "http://127.0.0.1:8000"
pytestmark = pytest.mark.e2e


def _up() -> bool:
    try:
        return httpx.get(f"{GATEWAY}/health", timeout=1).status_code == 200
    except httpx.HTTPError:
        return False


@pytest.fixture(scope="module")
def api():
    if not _up():
        pytest.skip("StockFlow is not running")
    with httpx.Client(base_url=f"{GATEWAY}/api", timeout=20) as client:
        yield client


def wait_for(predicate, timeout=10.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        result = predicate()
        if result:
            return result
        time.sleep(0.3)
    raise AssertionError("condition not met in time")


def test_order_drives_low_stock_reorder_and_receipt(api):
    sku = "HLM-5002"
    available = api.get(f"/inventory/stock/{sku}").json()["available"]
    policy = api.get(f"/catalog/products/{sku}/reorder-policy").json()
    quantity = max(1, available - policy["reorder_point"])

    order = api.post("/orders", json={"customer_email": "e2e@example.com", "lines": [{"sku": sku, "quantity": quantity}]}).json()
    assert order["status"] == "CONFIRMED"

    def open_reorder():
        pos = api.get("/purchasing/purchase-orders").json()
        return next((po for po in pos if po["source"] == "AUTO_REORDER" and po["status"] in ("DRAFT", "SUBMITTED")
                     and po["lines"][0]["sku"] == sku), None)

    po = wait_for(open_reorder)
    if po["status"] == "DRAFT":
        api.post(f"/purchasing/purchase-orders/{po['po_number']}/submit")
    before = api.get(f"/inventory/stock/{sku}").json()["on_hand"]
    api.post(f"/purchasing/purchase-orders/{po['po_number']}/receive")
    wait_for(lambda: api.get(f"/inventory/stock/{sku}").json()["on_hand"] >= before + po["lines"][0]["quantity"])
    wait_for(lambda: any(n["reference"] == order["order_number"] for n in api.get("/notifications").json()))
