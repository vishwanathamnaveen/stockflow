# StockFlow — Inventory & Order Management Platform

StockFlow is a multi-service inventory, order and procurement platform for a
distributor running several warehouses. It is built as eight small Python
(FastAPI) services that talk over REST and a lightweight event bus.

Everything runs locally with **Python only**: no Docker, RabbitMQ, Kafka,
Redis or Postgres. Each service owns a SQLite database and the event bus is a
small HTTP service backed by SQLite.

## Services

| Service | Port | Responsibility | Talks to |
|---|---|---|---|
| gateway | 8000 | Public entry point, routes `/api/<prefix>/...` | all |
| catalog | 8001 | Products, prices, standard cost, reorder policy | — |
| warehouse | 8002 | Warehouses and bins | — |
| inventory | 8003 | Stock levels, reservations, movement ledger | catalog, warehouse |
| sales-order | 8004 | Customer orders | catalog, inventory |
| purchasing | 8005 | Suppliers, purchase orders, auto-reorder | catalog |
| notification | 8006 | Event-driven (simulated) email | purchasing |
| event-bus | 8007 | Durable pub/sub over HTTP | subscribers |

See [docs/architecture.md](docs/architecture.md) for flows and diagrams.

## Quick start

Requires Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt

python scripts/run_local.py --reset     # terminal 1: starts all 8 services
python scripts/seed_data.py             # terminal 2: warehouses, suppliers, products, stock
python scripts/generate_traffic.py --orders 100
```

Open http://127.0.0.1:8000/docs (gateway) or any service's `/docs`.

## Tests

```bash
python scripts/run_tests.py                 # every suite, with per-test coverage
python -m pytest tests/e2e -m e2e           # end-to-end, needs the system running
```

## Order placement and retries

When an order is placed, sales-order reserves stock in inventory. If inventory
times out or returns a 5xx, the reservation call is retried **3 times** before
the order is rejected with `inventory_unavailable`.

## Feature flags

`config/flags.json` is re-read on every call, so flags can be flipped while the
system is running:

| Flag | Effect |
|---|---|
| `auto_reorder` | purchasing creates a draft PO on `stock.low` |
| `auto_submit_reorders` | auto-generated POs are submitted immediately |
| `inventory_reservation_delay_ms` | fault: delays reservations (causes timeouts in sales-order) |
| `notification_failure` | fault: notification handlers fail; event bus retries then dead-letters |

## Repository layout

```
config/          service registry, event subscriptions, feature flags
contracts/       OpenAPI per service (generated) and the event catalogue
docs/            architecture, business rules, ADRs, runbooks
libs/common/     shared library: db, events (outbox/inbox), http client, tracing, flags
services/<name>/ one folder per service: <package>/ and tests/
scripts/         run, seed, traffic, tests, contract export
tests/e2e/       end-to-end tests against the running system
var/             runtime output (databases, logs, traces, coverage) — gitignored
```
