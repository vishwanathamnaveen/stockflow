"""Load demo master data through the gateway: warehouses, bins, suppliers,
products and opening stock. Safe to re-run (409s are ignored).

    python scripts/seed_data.py
"""
from __future__ import annotations

import sys

import httpx

import _paths  # noqa: F401
from stockflow_common.settings import service_url

GATEWAY = service_url("gateway")

WAREHOUSES = [
    {"code": "HYD-01", "name": "Hyderabad Central DC", "city": "Hyderabad"},
    {"code": "BLR-01", "name": "Bengaluru North DC", "city": "Bengaluru"},
    {"code": "CHN-01", "name": "Chennai Port DC", "city": "Chennai"},
]
BINS = [("HYD-01", "A-01", "FAST"), ("HYD-01", "A-02", "FAST"), ("HYD-01", "B-01", "BULK"),
        ("BLR-01", "A-01", "FAST"), ("BLR-01", "B-01", "BULK"), ("CHN-01", "A-01", "GENERAL")]
SUPPLIERS = [
    {"code": "SUP-ACME", "name": "Acme Industrial Supplies", "email": "orders@acme.example", "lead_time_days": 5},
    {"code": "SUP-DECCAN", "name": "Deccan Electricals", "email": "sales@deccan.example", "lead_time_days": 3},
    {"code": "SUP-KAVERI", "name": "Kaveri Packaging", "email": "po@kaveri.example", "lead_time_days": 7},
]
PRODUCTS = [
    # sku, name, category, price, cost, reorder_point, reorder_qty, supplier, opening stock {warehouse: qty}
    ("DRL-1001", "Cordless Drill 18V", "power-tools", 649900, 412000, 10, 40, "SUP-ACME", {"HYD-01": 30, "BLR-01": 15}),
    ("DRL-1002", "Hammer Drill 750W", "power-tools", 459900, 280000, 8, 30, "SUP-ACME", {"HYD-01": 20}),
    ("SAW-2001", "Circular Saw 1400W", "power-tools", 799900, 510000, 5, 20, "SUP-ACME", {"BLR-01": 12, "CHN-01": 6}),
    ("CBL-3001", "Copper Cable 2.5mm 90m", "electrical", 389900, 250000, 25, 100, "SUP-DECCAN", {"HYD-01": 80, "CHN-01": 40}),
    ("SWT-3002", "Modular Switch 6A (10 pack)", "electrical", 129900, 70000, 30, 120, "SUP-DECCAN", {"HYD-01": 60, "BLR-01": 50}),
    ("MCB-3003", "MCB 32A Double Pole", "electrical", 89900, 52000, 15, 60, "SUP-DECCAN", {"BLR-01": 25}),
    ("BOX-4001", "Corrugated Box 18x12x10 (25)", "packaging", 74900, 41000, 40, 200, "SUP-KAVERI", {"HYD-01": 120, "CHN-01": 90}),
    ("TPE-4002", "Packing Tape 48mm (6 rolls)", "packaging", 34900, 18000, 50, 250, "SUP-KAVERI", {"HYD-01": 70}),
    ("GLV-5001", "Safety Gloves Nitrile (100)", "safety", 99900, 55000, 20, 80, None, {"HYD-01": 35, "BLR-01": 20}),
    ("HLM-5002", "Safety Helmet ISI", "safety", 44900, 23000, 12, 50, None, {"BLR-01": 14}),
]


def _post(client: httpx.Client, path: str, body: dict) -> None:
    response = client.post(f"{GATEWAY}{path}", json=body)
    if response.status_code not in (200, 201, 409):
        raise SystemExit(f"POST {path} failed: {response.status_code} {response.text}")


def main() -> int:
    with httpx.Client(timeout=15.0) as client:
        try:
            client.get(f"{GATEWAY}/health").raise_for_status()
        except httpx.HTTPError:
            print("gateway is not running; start it with: python scripts/run_local.py")
            return 1
        for wh in WAREHOUSES:
            _post(client, "/api/warehouses", wh)
        for code, bin_code, zone in BINS:
            _post(client, f"/api/warehouses/{code}/bins", {"code": bin_code, "zone": zone})
        for supplier in SUPPLIERS:
            _post(client, "/api/purchasing/suppliers", supplier)
        for sku, name, category, price, cost, rp, rq, supplier, stock in PRODUCTS:
            _post(client, "/api/catalog/products", {
                "sku": sku, "name": name, "category": category, "unit_price_cents": price,
                "standard_cost_cents": cost, "reorder_point": rp, "reorder_qty": rq, "preferred_supplier_code": supplier,
            })
        existing = {row["sku"] for row in client.get(f"{GATEWAY}/api/inventory/stock").json()}
        for sku, *_rest, stock in PRODUCTS:
            if sku in existing:
                continue
            for warehouse, qty in stock.items():
                _post(client, "/api/inventory/receipts", {
                    "warehouse_code": warehouse, "reference": "OPENING-BALANCE", "lines": [{"sku": sku, "quantity": qty}],
                })
    print(f"seeded {len(WAREHOUSES)} warehouses, {len(SUPPLIERS)} suppliers, {len(PRODUCTS)} products with opening stock")
    return 0


if __name__ == "__main__":
    sys.exit(main())
