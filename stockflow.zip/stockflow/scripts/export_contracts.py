"""Export every service's OpenAPI document to contracts/openapi/<service>.json.
Run after changing any endpoint; CI checks the files are up to date.

    python scripts/export_contracts.py          # write files
    python scripts/export_contracts.py --check  # fail if files are stale
"""
from __future__ import annotations

import argparse
import importlib
import json
import os
import sys

from _paths import COMMON, ROOT, SERVICES

os.environ.setdefault("STOCKFLOW_TRACING", "0")
os.environ.setdefault("STOCKFLOW_RELAY", "0")

import yaml  # noqa: E402

OUT = ROOT / "contracts" / "openapi"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    registry = yaml.safe_load((ROOT / "config" / "services.yaml").read_text())["services"]
    OUT.mkdir(parents=True, exist_ok=True)
    stale = []
    for name, cfg in registry.items():
        sys.path.insert(0, str(SERVICES / name))
        app = importlib.import_module(f"{cfg['package']}.main").app
        document = json.dumps(app.openapi(), indent=2, sort_keys=True) + "\n"
        target = OUT / f"{name}.json"
        if args.check:
            if not target.exists() or target.read_text() != document:
                stale.append(name)
        else:
            target.write_text(document)
            print(f"wrote {target.relative_to(ROOT)}")
    if stale:
        print("stale contracts: " + ", ".join(stale) + " (run scripts/export_contracts.py)")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
