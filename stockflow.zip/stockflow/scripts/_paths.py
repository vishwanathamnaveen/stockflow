"""Path helpers shared by the scripts (lets them import stockflow_common)."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMON = ROOT / "libs" / "common"
SERVICES = ROOT / "services"

if str(COMMON) not in sys.path:
    sys.path.insert(0, str(COMMON))


def service_dir(name: str) -> Path:
    return SERVICES / name
