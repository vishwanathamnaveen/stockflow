"""Start every StockFlow service as a local uvicorn process.

    python scripts/run_local.py                 # all services
    python scripts/run_local.py --only catalog inventory
    python scripts/run_local.py --reset         # delete local databases/traces first

Logs:   var/logs/<service>.log
Traces: var/traces/<service>.jsonl
Stop with Ctrl+C.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time

import httpx

from _paths import COMMON, ROOT, service_dir
from stockflow_common.settings import load_registry, service_url

# Start order: dependencies before dependents.
START_ORDER = ["event-bus", "catalog", "warehouse", "inventory", "purchasing", "sales-order", "notification", "gateway"]


def _wait_healthy(name: str, timeout: float = 20.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            if httpx.get(f"{service_url(name)}/health", timeout=1.0).status_code == 200:
                return True
        except httpx.HTTPError:
            pass
        time.sleep(0.3)
    return False


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--only", nargs="*", help="subset of services to start")
    parser.add_argument("--reset", action="store_true", help="delete var/data and var/traces before starting")
    args = parser.parse_args()

    registry = load_registry()["services"]
    names = [n for n in START_ORDER if not args.only or n in args.only]

    var = ROOT / "var"
    if args.reset:
        for sub in ("data", "traces", "logs"):
            shutil.rmtree(var / sub, ignore_errors=True)
    (var / "logs").mkdir(parents=True, exist_ok=True)

    processes: list[tuple[str, subprocess.Popen]] = []
    try:
        for name in names:
            cfg = registry[name]
            env = os.environ.copy()
            env["PYTHONPATH"] = os.pathsep.join([str(COMMON), str(service_dir(name)), env.get("PYTHONPATH", "")])
            env["PYTHONUNBUFFERED"] = "1"
            log_file = open(var / "logs" / f"{name}.log", "a", encoding="utf-8")
            proc = subprocess.Popen(
                [sys.executable, "-m", "uvicorn", f"{cfg['package']}.main:app", "--host", "127.0.0.1", "--port", str(cfg["port"])],
                cwd=service_dir(name),
                env=env,
                stdout=log_file,
                stderr=subprocess.STDOUT,
            )
            processes.append((name, proc))
            ok = _wait_healthy(name)
            print(f"  {'UP  ' if ok else 'FAIL'}  {name:<13} {service_url(name)}/docs")
            if not ok:
                print(f"        see var/logs/{name}.log")
        print("\nStockFlow is running. Gateway: http://127.0.0.1:8000/api/_routes  (Ctrl+C to stop)")
        while True:
            for name, proc in processes:
                if proc.poll() is not None:
                    print(f"!! {name} exited with code {proc.returncode}; see var/logs/{name}.log")
                    processes.remove((name, proc))
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nstopping...")
    finally:
        for _name, proc in processes:
            proc.terminate()
        for _name, proc in processes:
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
