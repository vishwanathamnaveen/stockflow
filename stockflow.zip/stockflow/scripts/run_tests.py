"""Run each service's tests in its own process and write quality evidence.

    python scripts/run_tests.py                  # all suites
    python scripts/run_tests.py inventory sales-order

Outputs (inputs for the quality/test graph):
  var/quality/<suite>-junit.xml     test results
  var/quality/<suite>-coverage.json per-test coverage (which test executed which lines)
"""
from __future__ import annotations

import os
import subprocess
import sys

from _paths import COMMON, ROOT, SERVICES

import yaml

QUALITY = ROOT / "var" / "quality"


def suites() -> dict[str, tuple[str, str]]:
    registry = yaml.safe_load((ROOT / "config" / "services.yaml").read_text())["services"]
    found = {"common": (str(COMMON), "stockflow_common")}
    for name, cfg in registry.items():
        found[name] = (str(SERVICES / name), cfg["package"])
    return found


def main(argv: list[str]) -> int:
    selected = suites()
    if argv:
        selected = {k: v for k, v in selected.items() if k in argv}
    QUALITY.mkdir(parents=True, exist_ok=True)
    failed = []
    for name, (directory, package) in selected.items():
        env = os.environ.copy()
        env["PYTHONPATH"] = os.pathsep.join([str(COMMON), directory])
        env["COVERAGE_FILE"] = str(QUALITY / f".coverage-{name}")
        cmd = [
            sys.executable, "-m", "pytest", "tests", "-q",
            f"--rootdir={ROOT}", f"-c={ROOT / 'pytest.ini'}",
            f"--cov={package}", f"--cov-config={ROOT / '.coveragerc'}", "--cov-context=test",
            f"--cov-report=json:{QUALITY / f'{name}-coverage.json'}", "--cov-report=term:skip-covered",
            f"--junitxml={QUALITY / f'{name}-junit.xml'}",
        ]
        print(f"\n=== {name} ===", flush=True)
        if subprocess.call(cmd, cwd=directory, env=env) != 0:
            failed.append(name)
    print("\nFAILED: " + ", ".join(failed) if failed else "\nall suites passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
