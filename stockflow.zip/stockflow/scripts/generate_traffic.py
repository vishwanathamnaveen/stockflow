"""Drive realistic traffic through the gateway so traces, logs and events
accumulate for the runtime graph.

    python scripts/generate_traffic.py --orders 60
    python scripts/generate_traffic.py --orders 200 --workers 8

Mix: most orders succeed; some are too large (rejected), some are cancelled,
most confirmed ones ship, and open purchase orders are submitted/received so
purchasing -> inventory -> notification event paths are exercised too.
"""
from __future__ import annotations

import argparse
import random
import sys
from concurrent.futures import ThreadPoolExecutor

import httpx

import _paths  # noqa: F401
from stockflow_common.settings import service_url

GATEWAY = service_url("gateway")
CUSTOMERS = ["ravi@example.com", "anita@example.com", "farhan@example.com", "meera@example.com", "john@example.com"]


def one_order(client: httpx.Client, skus: list[str], rng: random.Random) -> str:
    lines = [{"sku": sku, "quantity": rng.randint(1, 4)} for sku in rng.sample(skus, rng.randint(1, 3))]
    if rng.random() < 0.08:
        lines[0]["quantity"] = 500  # guaranteed insufficient stock
    if rng.random() < 0.03:
        lines.append({"sku": "NOPE-0000", "quantity": 1})  # unknown sku -> 422
    response = client.post(f"{GATEWAY}/api/orders", json={"customer_email": rng.choice(CUSTOMERS), "lines": lines})
    if response.status_code != 201:
        return f"http_{response.status_code}"
    order = response.json()
    if order["status"] != "CONFIRMED":
        return order["rejection_reason"] or order["status"]
    roll = rng.random()
    if roll < 0.15:
        client.post(f"{GATEWAY}/api/orders/{order['order_number']}/cancel")
        return "cancelled"
    if roll < 0.85:
        client.post(f"{GATEWAY}/api/orders/{order['order_number']}/ship")
        return "shipped"
    return "confirmed"


def process_purchase_orders(client: httpx.Client) -> int:
    handled = 0
    for po in client.get(f"{GATEWAY}/api/purchasing/purchase-orders", params={"status": "DRAFT"}).json():
        client.post(f"{GATEWAY}/api/purchasing/purchase-orders/{po['po_number']}/submit")
        handled += 1
    for po in client.get(f"{GATEWAY}/api/purchasing/purchase-orders", params={"status": "SUBMITTED"}).json():
        client.post(f"{GATEWAY}/api/purchasing/purchase-orders/{po['po_number']}/receive")
    return handled


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--orders", type=int, default=60)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    rng = random.Random(args.seed)

    with httpx.Client(timeout=30.0) as client:
        try:
            skus = [p["sku"] for p in client.get(f"{GATEWAY}/api/catalog/products", params={"active": True}).json()]
        except httpx.HTTPError:
            print("gateway not reachable; run scripts/run_local.py and scripts/seed_data.py first")
            return 1
        if not skus:
            print("no products; run scripts/seed_data.py first")
            return 1

        outcomes: dict[str, int] = {}
        batch = max(10, args.orders // 4)
        done = 0
        while done < args.orders:
            size = min(batch, args.orders - done)
            seeds = [rng.randint(0, 10**9) for _ in range(size)]
            with ThreadPoolExecutor(max_workers=args.workers) as pool:
                for result in pool.map(lambda s: one_order(client, skus, random.Random(s)), seeds):
                    outcomes[result] = outcomes.get(result, 0) + 1
            done += size
            process_purchase_orders(client)
        print(f"{args.orders} orders -> " + ", ".join(f"{k}: {v}" for k, v in sorted(outcomes.items())))
    return 0


if __name__ == "__main__":
    sys.exit(main())
