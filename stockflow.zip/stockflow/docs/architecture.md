# StockFlow architecture

## Context

StockFlow serves a distributor with warehouses in Hyderabad, Bengaluru and
Chennai. Sales staff and the web shop place customer orders; the procurement
team buys stock from suppliers; the fulfilment team ships from warehouses.

## Service map

```mermaid
flowchart LR
  client([Client]) --> gateway
  gateway --> catalog & warehouse & inventory & sales-order & purchasing & notification & event-bus
  sales-order -- REST --> catalog
  sales-order -- REST --> inventory
  inventory -- REST --> catalog
  inventory -- REST --> warehouse
  purchasing -- REST --> catalog
  notification -- REST --> purchasing
  catalog -. product.updated .-> bus[(event-bus)]
  inventory -. stock.low .-> bus
  sales-order -. order.* .-> bus
  purchasing -. purchase_order.* .-> bus
  bus -. product.updated .-> inventory
  bus -. stock.low .-> purchasing
  bus -. stock.low, order.*, purchase_order.* .-> notification
  bus -. purchase_order.received .-> inventory
```

Solid lines are synchronous REST calls; dotted lines are events.

## Key flows

**Place order.** sales-order prices each line from catalog, stores the order as
PENDING, then calls `POST /reservations` on inventory. On success the order is
CONFIRMED and `order.confirmed` is published; on 409 it is REJECTED
(insufficient stock).

**Low stock and reorder.** After each reservation inventory compares total
available stock with the product's reorder point (cached from catalog). At or
below it, inventory publishes `stock.low`. purchasing creates a draft purchase
order (if `auto_reorder` is on and no open PO exists for the SKU).
notification emails the inventory team.

**Receive goods.** When a purchase order is received, purchasing publishes
`purchase_order.received`; inventory adds the stock and records RECEIPT
movements.

**Cancel / ship.** Cancelling releases the reservation; shipping commits it,
reducing on-hand stock.

## Cross-cutting

- **Data ownership.** Each service owns its SQLite database (ADR-001). Cross-service
  references (sku, supplier_code, warehouse_code) are plain strings, validated by REST.
- **Events.** Transactional outbox on the producer, idempotent inbox on the
  consumer, delivery via the event bus with retries and dead-lettering (ADR-002).
- **Resilience.** Service-to-service calls use `stockflow_common.http_client`
  with per-client timeouts and retries (ADR-003).
- **Observability.** OpenTelemetry traces written as JSON lines to
  `var/traces/<service>.jsonl`; trace context flows through events (ADR-004).
