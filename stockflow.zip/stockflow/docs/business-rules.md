# Business rules

| ID | Rule | Implemented in |
|---|---|---|
| BR-001 | SKUs are unique, upper-case, letters/digits/hyphens. | catalog `schemas.ProductCreate` |
| BR-002 | Changing reorder point, reorder quantity, preferred supplier, standard cost or active status is a *policy change* and must be announced. | catalog `domain.update_product` |
| BR-010 | Stock reservations are all-or-nothing per order. | inventory `domain.reserve` |
| BR-011 | Available stock = on hand − reserved. | inventory `models.StockLevel.available` |
| BR-012 | Allocation takes stock from the warehouse with the most available first. | inventory `domain._plan_allocation` |
| BR-013 | `stock.low` is raised when total available ≤ reorder point. | inventory `domain.check_low_stock` |
| BR-014 | Reserving the same order twice returns the existing reservation. | inventory `domain.reserve` |
| BR-015 | Adjustments may not reduce on hand below reserved. | inventory `domain.adjust_stock` |
| BR-020 | Order prices come from the catalog at order time. | sales-order `domain.place_order` |
| BR-021 | Unknown or inactive SKUs make the whole order invalid. | sales-order `domain.place_order` |
| BR-022 | An order is CONFIRMED only if every line is reserved. | sales-order `domain.place_order` |
| BR-023 | Insufficient stock rejects the order (`insufficient_stock`). | sales-order `domain.place_order` |
| BR-024 | Inventory unavailable after retries rejects the order (`inventory_unavailable`). | sales-order `domain.place_order` |
| BR-025 | Only CONFIRMED orders can be cancelled or shipped. | sales-order `domain.cancel_order`, `ship_order` |
| BR-030 | PO line cost = catalog standard cost at creation. | purchasing `domain.create_po` |
| BR-031 | At most one open (DRAFT/SUBMITTED) PO per SKU from auto-reorder. | purchasing `domain.auto_reorder` |
| BR-032 | Auto-reorder uses the preferred supplier, else the first active supplier. | purchasing `domain.auto_reorder` |
| BR-033 | Only SUBMITTED purchase orders can be received. | purchasing `domain.receive_po` |
