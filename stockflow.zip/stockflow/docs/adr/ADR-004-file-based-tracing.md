# ADR-004: File-based OpenTelemetry traces

- Status: Accepted
- Date: 2026-08-18
- Deciders: Sara Collins

## Context
We want distributed traces locally without running a collector or Jaeger.

## Decision
Services use the OpenTelemetry SDK with FastAPI and HTTPX auto-instrumentation.
A custom exporter appends one JSON object per span to
`var/traces/<service>.jsonl`. Outgoing calls carry `peer.service`. Event
publish/consume spans carry `messaging.*` attributes, and trace context is
propagated through event headers, so a single trace covers
gateway → sales-order → inventory → event-bus → purchasing → notification.

Logs include `trace=<trace_id>` for correlation.

## Consequences
- Traces are plain files; any tool can read them.
- For a UI, add an OTLP exporter and run Jaeger (optional).
