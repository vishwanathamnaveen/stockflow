# ADR-002: Lightweight HTTP event bus with transactional outbox

- Status: Accepted
- Date: 2026-08-10
- Deciders: Priya Raman, Sara Collins

## Context
Services need asynchronous notifications (low stock, goods received, order
status). RabbitMQ or Kafka would add infrastructure that every developer must
run locally, which slows onboarding and demos.

## Decision
- A small **event-bus** service stores events in SQLite and pushes them to
  subscribers over HTTP (`POST /events/receive`). Routing is declared in
  `config/subscriptions.yaml`; payloads in `contracts/events.yaml`.
- Producers use a **transactional outbox**: the event row is written in the
  same transaction as the business change and relayed by a background thread.
- Consumers use an **inbox** table keyed by event id, so redelivery is safe.
- Delivery is at-least-once with exponential backoff; after 5 failed attempts
  a delivery is marked DEAD and can be redelivered via the API.

## Consequences
- No ordering guarantee across topics.
- The bus is a single point of failure; outbox rows accumulate while it is
  down and are relayed when it returns.
- Swapping to a real broker later only changes the relay and the bus.
