# ADR-001: Database per service (SQLite)

- Status: Accepted
- Date: 2026-08-03
- Deciders: Priya Raman, Arjun Mehta

## Context
Services must deploy and evolve independently. A shared schema would couple
release cycles and hide cross-service dependencies inside SQL joins.

## Decision
Each service owns exactly one database and no other service reads it. For
local development and demos the database is SQLite (`var/data/<service>.db`),
configurable per service via `<SERVICE>_DATABASE_URL`.

Cross-service references (sku, warehouse_code, supplier_code) are stored as
plain values and validated through the owning service's REST API.

## Consequences
- No foreign keys across services; referential integrity is eventual.
- Reporting across services needs events or API composition.
- SQLite limits write concurrency; WAL mode is enabled. Production would move
  to Postgres without code changes (SQLAlchemy).
