# ADR-003: Retry policy for stock reservation

- Status: Accepted (supersedes the initial policy of 3 retries)
- Date: 2026-09-02
- Deciders: Arjun Mehta, Tom Walker

## Context
Order placement calls inventory `POST /reservations` synchronously. Under load,
3 retries with a 2 s timeout kept customers waiting up to ~9 s and multiplied
load on an already slow inventory service (incident INC-031).

## Decision
- Retry the reservation call **at most 2 times** (3 attempts in total).
- Retry only on timeout, connection error or HTTP 5xx. Never retry 4xx:
  a 409 means insufficient stock and is a business answer.
- Timeout per attempt: 2 s. Linear backoff 0.3 s × attempt.
- Configurable via `RESERVATION_MAX_RETRIES`, `RESERVATION_TIMEOUT_SECONDS`.
- After retries are exhausted the order is REJECTED with `inventory_unavailable`.

## Consequences
- Worst-case order latency drops to about 7 s.
- More orders are rejected during inventory brownouts; customers can retry.
