# Runbook: event bus

## Symptoms
- Notifications not arriving, auto-reorders not created, receipts not reflected in stock.

## Checks
1. `GET /api/events/deliveries?status=DEAD` — dead-lettered deliveries.
2. `GET /api/events/deliveries?status=PENDING` — backlog.
3. Producer outbox backlog: rows with `published_at IS NULL` in the producer's `outbox` table.
4. Logs: `var/logs/event-bus.log`, look for `dead-lettered`.

## Actions
- Fix the failing consumer first (check its log for the stack trace).
- Redeliver: `POST /api/events/deliveries/<id>/redeliver`.
- Consumers are idempotent (inbox), so redelivery is safe.
