# Runbook: stock discrepancy

## Symptoms
- Available stock looks lower than physical stock, or orders are rejected with
  `insufficient_stock` although shelves are full.

## Checks
1. `GET /api/inventory/stock/<sku>` — compare on_hand, reserved, available.
2. `GET /api/inventory/movements?sku=<sku>` — the ledger explains every change.
3. For each ACTIVE reservation, check the order status in sales-order.

## Actions
- Correct on_hand with `POST /api/inventory/adjustments` (reason required).
- Release stale reservations with `POST /api/inventory/reservations/<order>/release`.
