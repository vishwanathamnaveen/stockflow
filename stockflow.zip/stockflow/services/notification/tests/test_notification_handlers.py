import pytest

from notification_service.clients import clients
from stockflow_common.testing import set_flag


class FakePurchasing:
    def supplier_email(self, code):
        return {"SUP-ACME": "orders@acme.example"}.get(code)


@pytest.fixture(autouse=True)
def fakes():
    clients.purchasing = FakePurchasing()
    yield


def send(client, topic, payload, event_id="e1"):
    return client.post("/events/receive", json={"event_id": event_id, "topic": topic, "source": "test", "payload": payload})


ORDER = {"order_number": "SO-1", "customer_email": "ravi@example.com", "total_cents": 150000, "lines": [{"sku": "A", "quantity": 1}]}


def test_order_confirmed_emails_customer(client):
    send(client, "order.confirmed", ORDER)
    [note] = client.get("/notifications").json()
    assert note["recipient"] == "ravi@example.com"
    assert "INR 1,500.00" in note["body"]


def test_purchase_order_submitted_emails_supplier(client):
    send(client, "purchase_order.submitted", {"po_number": "PO-1", "supplier_code": "SUP-ACME", "warehouse_code": "HYD-01", "lines": [{"sku": "A", "quantity": 4}]})
    assert client.get("/notifications").json()[0]["recipient"] == "orders@acme.example"


def test_stock_low_emails_inventory_team(client):
    send(client, "stock.low", {"sku": "A", "available": 2, "reorder_point": 5, "reorder_qty": 10})
    assert client.get("/notifications", params={"event_type": "stock.low"}).json()[0]["recipient"] == "inventory-team@stockflow.local"


def test_failure_flag_makes_handler_fail(client):
    set_flag("notification_failure", True)
    with pytest.raises(RuntimeError):
        send(client, "order.confirmed", ORDER)
