"""Turns domain events into (simulated) emails."""
from __future__ import annotations

import os

from sqlalchemy.orm import Session

from stockflow_common.flags import is_enabled

from .clients import clients
from .models import Notification

INVENTORY_TEAM_EMAIL = os.environ.get("INVENTORY_TEAM_EMAIL", "inventory-team@stockflow.local")


class NotificationFailure(RuntimeError):
    pass


def _send(session: Session, *, recipient: str, subject: str, body: str, event_type: str, reference: str) -> None:
    if is_enabled("notification_failure"):
        raise NotificationFailure("fault injection: notification_failure flag is on")
    session.add(Notification(recipient=recipient, subject=subject, body=body, event_type=event_type, reference=reference))


def _money(cents: int) -> str:
    return f"INR {cents / 100:,.2f}"


def on_order_confirmed(session: Session, payload: dict) -> None:
    _send(
        session,
        recipient=payload["customer_email"],
        subject=f"Order {payload['order_number']} confirmed",
        body=f"Thanks! {len(payload['lines'])} line(s), total {_money(payload['total_cents'])}.",
        event_type="order.confirmed",
        reference=payload["order_number"],
    )


def on_order_cancelled(session: Session, payload: dict) -> None:
    _send(
        session,
        recipient=payload["customer_email"],
        subject=f"Order {payload['order_number']} cancelled",
        body="Your order has been cancelled and any payment will be refunded.",
        event_type="order.cancelled",
        reference=payload["order_number"],
    )


def on_order_shipped(session: Session, payload: dict) -> None:
    _send(
        session,
        recipient=payload["customer_email"],
        subject=f"Order {payload['order_number']} shipped",
        body="Your order is on its way.",
        event_type="order.shipped",
        reference=payload["order_number"],
    )


def on_stock_low(session: Session, payload: dict) -> None:
    _send(
        session,
        recipient=INVENTORY_TEAM_EMAIL,
        subject=f"Low stock: {payload['sku']}",
        body=f"Available {payload['available']} is at or below reorder point {payload['reorder_point']}.",
        event_type="stock.low",
        reference=payload["sku"],
    )


def on_purchase_order_submitted(session: Session, payload: dict) -> None:
    recipient = clients.purchasing.supplier_email(payload["supplier_code"]) or INVENTORY_TEAM_EMAIL
    lines = ", ".join(f"{line['quantity']} x {line['sku']}" for line in payload["lines"])
    _send(
        session,
        recipient=recipient,
        subject=f"Purchase order {payload['po_number']}",
        body=f"Please deliver to {payload['warehouse_code']}: {lines}.",
        event_type="purchase_order.submitted",
        reference=payload["po_number"],
    )


def on_purchase_order_received(session: Session, payload: dict) -> None:
    _send(
        session,
        recipient=INVENTORY_TEAM_EMAIL,
        subject=f"Goods received for {payload['po_number']}",
        body=f"Received into {payload['warehouse_code']}.",
        event_type="purchase_order.received",
        reference=payload["po_number"],
    )


HANDLERS = {
    "order.confirmed": on_order_confirmed,
    "order.cancelled": on_order_cancelled,
    "order.shipped": on_order_shipped,
    "stock.low": on_stock_low,
    "purchase_order.submitted": on_purchase_order_submitted,
    "purchase_order.received": on_purchase_order_received,
}
