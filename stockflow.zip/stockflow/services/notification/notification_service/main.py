"""Notification service: event-driven (simulated) email."""
from stockflow_common.app_factory import create_service_app
from stockflow_common.events import build_event_router

from .api import router
from .database import db
from .handlers import HANDLERS
from .models import Base, Inbox

app = create_service_app(
    "notification",
    description="Consumes order, stock and purchasing events and records outgoing emails.",
    on_startup=[lambda: db.create_all(Base)],
)
app.include_router(router)
app.include_router(build_event_router(handlers=HANDLERS, session_dependency=db.session, inbox_model=Inbox))
