from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session

from .database import db
from .models import Notification

router = APIRouter(prefix="/notifications", tags=["notifications"])


class NotificationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    channel: str
    recipient: str
    subject: str
    body: str
    event_type: str
    reference: str
    created_at: datetime


@router.get("", response_model=list[NotificationOut])
def list_notifications(
    event_type: str | None = None, recipient: str | None = None, limit: int = 100, session: Session = Depends(db.session)
):
    query = select(Notification).order_by(Notification.id.desc()).limit(limit)
    if event_type:
        query = query.where(Notification.event_type == event_type)
    if recipient:
        query = query.where(Notification.recipient == recipient)
    return session.scalars(query).all()
