"""Outbound REST dependencies of the notification service."""
from __future__ import annotations

from stockflow_common.http_client import ServiceClient


class PurchasingClient:
    def __init__(self) -> None:
        self._http = ServiceClient("purchasing", timeout=3.0, max_retries=1)

    def supplier_email(self, supplier_code: str) -> str | None:
        response = self._http.get(f"/suppliers/{supplier_code}")
        return response.json()["email"] if response.status_code == 200 else None


class Clients:
    def __init__(self) -> None:
        self.purchasing = PurchasingClient()


clients = Clients()
