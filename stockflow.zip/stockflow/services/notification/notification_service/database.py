from stockflow_common.db import Database
from stockflow_common.settings import ServiceSettings

settings = ServiceSettings.for_service("notification")
db = Database(settings.database_url)
