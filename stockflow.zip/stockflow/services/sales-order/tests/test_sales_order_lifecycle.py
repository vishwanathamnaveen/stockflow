import httpx
import pytest

from sales_order_service.clients import clients
from sales_order_service.models import Outbox
from stockflow_common.errors import DownstreamUnavailable

CATALOG = {
    "DRL-1001": {"sku": "DRL-1001", "unit_price_cents": 1000, "active": True},
    "OLD-0001": {"sku": "OLD-0001", "unit_price_cents": 500, "active": False},
}


class FakeCatalog:
    def get_product(self, sku):
        return CATALOG.get(sku)


class FakeInventory:
    def __init__(self):
        self.reserve_response = httpx.Response(201, json=[])
        self.reserve_error = None
        self.calls = []

    def reserve(self, order_id, lines):
        self.calls.append(("reserve", order_id, lines))
        if self.reserve_error:
            raise self.reserve_error
        return self.reserve_response

    def release(self, order_id):
        self.calls.append(("release", order_id))
        return httpx.Response(200, json=[])

    def commit(self, order_id):
        self.calls.append(("commit", order_id))
        return httpx.Response(200, json=[])


@pytest.fixture(autouse=True)
def fakes():
    clients.catalog = FakeCatalog()
    clients.inventory = FakeInventory()
    yield clients


ORDER = {"customer_email": "ravi@example.com", "lines": [{"sku": "DRL-1001", "quantity": 3}]}


def topics(session):
    return [row.topic for row in session.query(Outbox)]


def test_order_confirmed_when_stock_reserved(client, session):
    body = client.post("/orders", json=ORDER).json()
    assert body["status"] == "CONFIRMED"
    assert body["total_cents"] == 3000
    assert topics(session) == ["order.confirmed"]


def test_price_comes_from_catalog_not_client(client):
    body = client.post("/orders", json={**ORDER, "lines": [{"sku": "DRL-1001", "quantity": 1, "unit_price_cents": 1}]}).json()
    assert body["lines"][0]["unit_price_cents"] == 1000


def test_inactive_or_unknown_sku_is_422(client, fakes):
    assert client.post("/orders", json={**ORDER, "lines": [{"sku": "OLD-0001", "quantity": 1}]}).status_code == 422
    assert client.post("/orders", json={**ORDER, "lines": [{"sku": "NOPE-1", "quantity": 1}]}).status_code == 422
    assert fakes.inventory.calls == []


def test_insufficient_stock_rejects_order(client, fakes, session):
    fakes.inventory.reserve_response = httpx.Response(409, json={"error": "conflict"})
    body = client.post("/orders", json=ORDER).json()
    assert (body["status"], body["rejection_reason"]) == ("REJECTED", "insufficient_stock")
    assert topics(session) == []


def test_inventory_unavailable_rejects_order(client, fakes):
    fakes.inventory.reserve_error = DownstreamUnavailable("inventory", "ReadTimeout")
    body = client.post("/orders", json=ORDER).json()
    assert (body["status"], body["rejection_reason"]) == ("REJECTED", "inventory_unavailable")


def test_cancel_releases_reservation(client, fakes, session):
    number = client.post("/orders", json=ORDER).json()["order_number"]
    assert client.post(f"/orders/{number}/cancel").json()["status"] == "CANCELLED"
    assert ("release", number) in fakes.inventory.calls
    assert "order.cancelled" in topics(session)


def test_ship_commits_reservation(client, fakes):
    number = client.post("/orders", json=ORDER).json()["order_number"]
    assert client.post(f"/orders/{number}/ship").json()["status"] == "SHIPPED"
    assert ("commit", number) in fakes.inventory.calls


def test_cannot_ship_rejected_order(client, fakes):
    fakes.inventory.reserve_response = httpx.Response(409, json={})
    number = client.post("/orders", json=ORDER).json()["order_number"]
    assert client.post(f"/orders/{number}/ship").status_code == 409
