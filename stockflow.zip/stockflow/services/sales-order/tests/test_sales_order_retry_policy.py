"""ADR-003: reservation calls are retried on timeout/5xx only."""
import httpx

from sales_order_service import config
from sales_order_service.clients import InventoryClient


def test_default_retry_count_matches_adr_003():
    assert config.RESERVATION_MAX_RETRIES == 2


def test_inventory_client_retries_timeouts(monkeypatch):
    attempts = []

    def handler(request):
        attempts.append(request)
        if len(attempts) <= config.RESERVATION_MAX_RETRIES:
            raise httpx.ReadTimeout("slow", request=request)
        return httpx.Response(201, json=[])

    inventory = InventoryClient()
    inventory._http._client = httpx.Client(base_url="http://inventory", transport=httpx.MockTransport(handler))
    inventory._http.backoff_seconds = 0
    assert inventory.reserve("SO-1", [{"sku": "A", "quantity": 1}]).status_code == 201
    assert len(attempts) == config.RESERVATION_MAX_RETRIES + 1


def test_inventory_client_does_not_retry_conflict():
    attempts = []

    def handler(request):
        attempts.append(request)
        return httpx.Response(409, json={})

    inventory = InventoryClient()
    inventory._http._client = httpx.Client(base_url="http://inventory", transport=httpx.MockTransport(handler))
    assert inventory.reserve("SO-1", [{"sku": "A", "quantity": 1}]).status_code == 409
    assert len(attempts) == 1
