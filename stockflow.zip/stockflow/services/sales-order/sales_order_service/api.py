from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from . import domain
from .clients import clients
from .database import db
from .schemas import OrderCreate, OrderOut

router = APIRouter(prefix="/orders", tags=["orders"])


@router.post("", response_model=OrderOut, status_code=201)
def place_order(data: OrderCreate, session: Session = Depends(db.session)):
    return domain.place_order(session, clients, data)


@router.get("", response_model=list[OrderOut])
def list_orders(status: str | None = None, limit: int = 100, session: Session = Depends(db.session)):
    return domain.list_orders(session, status, limit)


@router.get("/{order_number}", response_model=OrderOut)
def get_order(order_number: str, session: Session = Depends(db.session)):
    return domain.get_order(session, order_number)


@router.post("/{order_number}/cancel", response_model=OrderOut)
def cancel_order(order_number: str, session: Session = Depends(db.session)):
    return domain.cancel_order(session, clients, order_number)


@router.post("/{order_number}/ship", response_model=OrderOut)
def ship_order(order_number: str, session: Session = Depends(db.session)):
    return domain.ship_order(session, clients, order_number)
