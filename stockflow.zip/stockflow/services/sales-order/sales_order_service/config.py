"""Sales-order runtime configuration.

Reservation retry policy is defined in ADR-003: retry the inventory
reservation call only on timeout / connection error / 5xx, never on 4xx.
"""
from stockflow_common.settings import env_float, env_int

RESERVATION_MAX_RETRIES = env_int("RESERVATION_MAX_RETRIES", 2)
RESERVATION_TIMEOUT_SECONDS = env_float("RESERVATION_TIMEOUT_SECONDS", 2.0)
RESERVATION_BACKOFF_SECONDS = env_float("RESERVATION_BACKOFF_SECONDS", 0.3)
MAX_LINES_PER_ORDER = env_int("MAX_LINES_PER_ORDER", 20)
