"""Order lifecycle.

Business rules (docs/business-rules.md):
  BR-020 Prices are taken from the catalog at order time, never from the client.
  BR-021 Inactive or unknown SKUs make the whole order invalid (422).
  BR-022 An order is CONFIRMED only if inventory reserves every line.
  BR-023 Insufficient stock -> REJECTED (reason insufficient_stock).
  BR-024 Inventory unavailable after retries -> REJECTED (reason inventory_unavailable).
  BR-025 Only CONFIRMED orders can be cancelled or shipped.
"""
from __future__ import annotations

import logging
import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from stockflow_common.errors import Conflict, DownstreamUnavailable, NotFound, ValidationFailed
from stockflow_common.events import publish_event

from . import config
from .clients import Clients
from .models import Order, OrderLine, Outbox
from .schemas import OrderCreate

log = logging.getLogger(__name__)
SOURCE = "sales-order"


def _new_order_number() -> str:
    return f"SO-{uuid.uuid4().hex[:8].upper()}"


def get_order(session: Session, order_number: str) -> Order:
    order = session.scalar(select(Order).where(Order.order_number == order_number))
    if order is None:
        raise NotFound(f"order {order_number} not found")
    return order


def list_orders(session: Session, status: str | None = None, limit: int = 100) -> list[Order]:
    query = select(Order).order_by(Order.id.desc()).limit(limit)
    if status:
        query = query.where(Order.status == status.upper())
    return list(session.scalars(query))


def _order_payload(order: Order) -> dict:
    return {
        "order_number": order.order_number,
        "customer_email": order.customer_email,
        "total_cents": order.total_cents,
        "lines": [{"sku": line.sku, "quantity": line.quantity} for line in order.lines],
    }


def place_order(session: Session, clients: Clients, data: OrderCreate) -> Order:
    if len(data.lines) > config.MAX_LINES_PER_ORDER:
        raise ValidationFailed(f"an order may have at most {config.MAX_LINES_PER_ORDER} lines")

    order = Order(order_number=_new_order_number(), customer_email=data.customer_email, status="PENDING")
    for line in data.lines:
        product = clients.catalog.get_product(line.sku)
        if product is None or not product.get("active", False):
            raise ValidationFailed(f"sku {line.sku} is unknown or inactive", details={"sku": line.sku})
        unit_price = product["unit_price_cents"]
        order.lines.append(
            OrderLine(sku=line.sku, quantity=line.quantity, unit_price_cents=unit_price, line_total_cents=unit_price * line.quantity)
        )
    order.total_cents = sum(line.line_total_cents for line in order.lines)
    session.add(order)
    session.commit()

    try:
        response = clients.inventory.reserve(
            order.order_number, [{"sku": line.sku, "quantity": line.quantity} for line in order.lines]
        )
    except DownstreamUnavailable as exc:
        log.error("reservation failed for %s: %s", order.order_number, exc)
        order.status = "REJECTED"
        order.rejection_reason = "inventory_unavailable"
        session.commit()
        return order

    if response.status_code == 409:
        order.status = "REJECTED"
        order.rejection_reason = "insufficient_stock"
    elif response.is_success:
        order.status = "CONFIRMED"
        publish_event(session, Outbox, topic="order.confirmed", payload=_order_payload(order), source=SOURCE)
    else:
        order.status = "REJECTED"
        order.rejection_reason = f"inventory_error_{response.status_code}"
    session.commit()
    return order


def cancel_order(session: Session, clients: Clients, order_number: str) -> Order:
    order = get_order(session, order_number)
    if order.status != "CONFIRMED":
        raise Conflict(f"cannot cancel order in status {order.status}")
    response = clients.inventory.release(order.order_number)
    if not response.is_success:
        raise Conflict(f"inventory refused release: {response.text}")
    order.status = "CANCELLED"
    publish_event(session, Outbox, topic="order.cancelled", payload=_order_payload(order), source=SOURCE)
    session.commit()
    return order


def ship_order(session: Session, clients: Clients, order_number: str) -> Order:
    order = get_order(session, order_number)
    if order.status != "CONFIRMED":
        raise Conflict(f"cannot ship order in status {order.status}")
    response = clients.inventory.commit(order.order_number)
    if not response.is_success:
        raise Conflict(f"inventory refused commit: {response.text}")
    order.status = "SHIPPED"
    publish_event(session, Outbox, topic="order.shipped", payload=_order_payload(order), source=SOURCE)
    session.commit()
    return order
