"""Outbound REST dependencies of the sales-order service."""
from __future__ import annotations

import httpx

from stockflow_common.http_client import ServiceClient

from . import config


class CatalogClient:
    def __init__(self) -> None:
        self._http = ServiceClient("catalog", timeout=3.0, max_retries=1)

    def get_product(self, sku: str) -> dict | None:
        response = self._http.get(f"/products/{sku}")
        return None if response.status_code == 404 else response.json()


class InventoryClient:
    def __init__(self) -> None:
        self._http = ServiceClient(
            "inventory",
            timeout=config.RESERVATION_TIMEOUT_SECONDS,
            max_retries=config.RESERVATION_MAX_RETRIES,
            backoff_seconds=config.RESERVATION_BACKOFF_SECONDS,
        )

    def reserve(self, order_id: str, lines: list[dict]) -> httpx.Response:
        return self._http.post("/reservations", json={"order_id": order_id, "lines": lines})

    def release(self, order_id: str) -> httpx.Response:
        return self._http.post(f"/reservations/{order_id}/release")

    def commit(self, order_id: str) -> httpx.Response:
        return self._http.post(f"/reservations/{order_id}/commit")


class Clients:
    def __init__(self) -> None:
        self.catalog = CatalogClient()
        self.inventory = InventoryClient()


clients = Clients()
