from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class OrderLineIn(BaseModel):
    sku: str
    quantity: int = Field(gt=0, le=1000)


class OrderCreate(BaseModel):
    customer_email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    lines: list[OrderLineIn] = Field(min_length=1)


class OrderLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    sku: str
    quantity: int
    unit_price_cents: int
    line_total_cents: int


class OrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    order_number: str
    customer_email: str
    status: str
    total_cents: int
    rejection_reason: str | None
    created_at: datetime
    lines: list[OrderLineOut]
