"""Sales-order service: customer orders and their lifecycle."""
from stockflow_common.app_factory import create_service_app
from stockflow_common.events import OutboxRelay

from .api import router
from .database import db
from .models import Base, Outbox

relay = OutboxRelay(db.SessionLocal, Outbox, source="sales-order")

app = create_service_app(
    "sales-order",
    description="Customer orders. Prices come from catalog; stock is reserved in inventory.",
    on_startup=[lambda: db.create_all(Base), relay.start],
    on_shutdown=[relay.stop],
)
app.include_router(router)
