from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from stockflow_common.errors import Conflict, NotFound

from .database import db
from .models import Bin, Warehouse
from .schemas import BinCreate, BinOut, WarehouseCreate, WarehouseOut

router = APIRouter(prefix="/warehouses", tags=["warehouses"])


def _get_warehouse(session: Session, code: str) -> Warehouse:
    warehouse = session.scalar(select(Warehouse).where(Warehouse.code == code))
    if warehouse is None:
        raise NotFound(f"warehouse {code} not found", details={"warehouse_code": code})
    return warehouse


@router.post("", response_model=WarehouseOut, status_code=201)
def create_warehouse(data: WarehouseCreate, session: Session = Depends(db.session)):
    if session.scalar(select(Warehouse).where(Warehouse.code == data.code)):
        raise Conflict(f"warehouse {data.code} already exists")
    warehouse = Warehouse(**data.model_dump())
    session.add(warehouse)
    session.commit()
    return warehouse


@router.get("", response_model=list[WarehouseOut])
def list_warehouses(active: bool | None = None, session: Session = Depends(db.session)):
    query = select(Warehouse).order_by(Warehouse.code)
    if active is not None:
        query = query.where(Warehouse.active == active)
    return session.scalars(query).all()


@router.get("/{code}", response_model=WarehouseOut)
def get_warehouse(code: str, session: Session = Depends(db.session)):
    return _get_warehouse(session, code)


@router.post("/{code}/bins", response_model=BinOut, status_code=201)
def create_bin(code: str, data: BinCreate, session: Session = Depends(db.session)):
    warehouse = _get_warehouse(session, code)
    if any(b.code == data.code for b in warehouse.bins):
        raise Conflict(f"bin {data.code} already exists in {code}")
    bin_ = Bin(warehouse=warehouse, **data.model_dump())
    session.add(bin_)
    session.commit()
    return bin_


@router.get("/{code}/bins", response_model=list[BinOut])
def list_bins(code: str, session: Session = Depends(db.session)):
    return _get_warehouse(session, code).bins
