from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class WarehouseCreate(BaseModel):
    code: str = Field(pattern=r"^[A-Z]{3}-\d{2}$", description="e.g. HYD-01")
    name: str
    city: str


class WarehouseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    code: str
    name: str
    city: str
    active: bool


class BinCreate(BaseModel):
    code: str
    zone: str = "GENERAL"
    capacity_units: int = Field(default=1000, gt=0)


class BinOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    code: str
    zone: str
    capacity_units: int
