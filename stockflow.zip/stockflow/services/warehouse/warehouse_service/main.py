"""Warehouse service: warehouses and bins. Leaf service (no outbound calls)."""
from stockflow_common.app_factory import create_service_app

from .api import router
from .database import db
from .models import Base

app = create_service_app(
    "warehouse",
    description="Warehouses and storage bins.",
    on_startup=[lambda: db.create_all(Base)],
)
app.include_router(router)
