def test_create_warehouse_and_bins(client):
    assert client.post("/warehouses", json={"code": "HYD-01", "name": "Hyderabad DC", "city": "Hyderabad"}).status_code == 201
    assert client.post("/warehouses/HYD-01/bins", json={"code": "A-01", "zone": "FAST"}).status_code == 201
    assert [b["code"] for b in client.get("/warehouses/HYD-01/bins").json()] == ["A-01"]


def test_warehouse_code_format_enforced(client):
    assert client.post("/warehouses", json={"code": "hyd1", "name": "x", "city": "y"}).status_code == 422


def test_duplicate_bin_rejected(client):
    client.post("/warehouses", json={"code": "HYD-01", "name": "Hyderabad DC", "city": "Hyderabad"})
    client.post("/warehouses/HYD-01/bins", json={"code": "A-01"})
    assert client.post("/warehouses/HYD-01/bins", json={"code": "A-01"}).status_code == 409


def test_unknown_warehouse_404(client):
    assert client.get("/warehouses/XXX-99").status_code == 404
