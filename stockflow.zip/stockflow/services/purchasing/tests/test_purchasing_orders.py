import json

import pytest

from purchasing_service.clients import clients
from purchasing_service.models import Outbox
from stockflow_common.testing import set_flag

POLICIES = {
    "DRL-1001": {"sku": "DRL-1001", "reorder_point": 10, "reorder_qty": 40, "preferred_supplier_code": "SUP-ACME", "standard_cost_cents": 400},
    "GLV-5001": {"sku": "GLV-5001", "reorder_point": 20, "reorder_qty": 80, "preferred_supplier_code": None, "standard_cost_cents": 50},
}


class FakeCatalog:
    def get_product(self, sku):
        return POLICIES[sku]

    def get_reorder_policy(self, sku):
        return POLICIES[sku]


@pytest.fixture(autouse=True)
def fakes(client):
    clients.catalog = FakeCatalog()
    client.post("/suppliers", json={"code": "SUP-ACME", "name": "Acme", "email": "orders@acme.example"})
    client.post("/suppliers", json={"code": "SUP-BETA", "name": "Beta", "email": "po@beta.example"})
    yield clients


def low(sku, event_id="e1"):
    return {"event_id": event_id, "topic": "stock.low", "source": "inventory", "payload": {"sku": sku, "available": 1, "reorder_point": 10, "reorder_qty": 40}}


def test_manual_po_uses_standard_cost(client):
    po = client.post("/purchase-orders", json={"supplier_code": "SUP-ACME", "warehouse_code": "HYD-01", "lines": [{"sku": "DRL-1001", "quantity": 5}]}).json()
    assert po["status"] == "DRAFT" and po["lines"][0]["unit_cost_cents"] == 400


def test_submit_then_receive_publishes_events(client, session):
    number = client.post("/purchase-orders", json={"supplier_code": "SUP-ACME", "warehouse_code": "HYD-01", "lines": [{"sku": "DRL-1001", "quantity": 5}]}).json()["po_number"]
    assert client.post(f"/purchase-orders/{number}/receive").status_code == 409  # must be submitted first
    client.post(f"/purchase-orders/{number}/submit")
    assert client.post(f"/purchase-orders/{number}/receive").json()["status"] == "RECEIVED"
    received = json.loads(session.query(Outbox).filter_by(topic="purchase_order.received").one().payload)
    assert received["lines"] == [{"sku": "DRL-1001", "quantity": 5}]


def test_stock_low_creates_auto_reorder_with_preferred_supplier(client):
    client.post("/events/receive", json=low("DRL-1001"))
    pos = client.get("/purchase-orders").json()
    assert len(pos) == 1
    assert (pos[0]["source"], pos[0]["supplier_code"], pos[0]["lines"][0]["quantity"]) == ("AUTO_REORDER", "SUP-ACME", 40)


def test_auto_reorder_falls_back_to_first_active_supplier(client):
    client.post("/events/receive", json=low("GLV-5001"))
    assert client.get("/purchase-orders").json()[0]["supplier_code"] == "SUP-ACME"


def test_only_one_open_po_per_sku(client):
    client.post("/events/receive", json=low("DRL-1001", "e1"))
    client.post("/events/receive", json=low("DRL-1001", "e2"))
    assert len(client.get("/purchase-orders").json()) == 1


def test_auto_reorder_respects_flag(client):
    set_flag("auto_reorder", False)
    client.post("/events/receive", json=low("DRL-1001"))
    assert client.get("/purchase-orders").json() == []


def test_auto_submit_flag_submits_reorders(client):
    set_flag("auto_submit_reorders", True)
    client.post("/events/receive", json=low("DRL-1001"))
    assert client.get("/purchase-orders").json()[0]["status"] == "SUBMITTED"
