"""Purchasing business logic.

Business rules (docs/business-rules.md):
  BR-030 Unit cost on a PO line is the catalog standard cost at creation time.
  BR-031 Auto-reorder creates at most one open (DRAFT or SUBMITTED) PO per SKU.
  BR-032 Auto-reorder uses the product's preferred supplier, else the first active supplier.
  BR-033 Only SUBMITTED purchase orders can be received.
"""
from __future__ import annotations

import logging
import os
import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from stockflow_common.errors import Conflict, NotFound, ValidationFailed
from stockflow_common.events import publish_event
from stockflow_common.flags import is_enabled

from .clients import Clients
from .models import Outbox, PurchaseOrder, PurchaseOrderLine, Supplier
from .schemas import POLineIn, PurchaseOrderCreate, SupplierCreate

log = logging.getLogger(__name__)
SOURCE = "purchasing"
DEFAULT_RECEIVING_WAREHOUSE = os.environ.get("DEFAULT_RECEIVING_WAREHOUSE", "HYD-01")
OPEN_STATUSES = ("DRAFT", "SUBMITTED")


def _new_po_number() -> str:
    return f"PO-{uuid.uuid4().hex[:8].upper()}"


# ---------------------------------------------------------------- suppliers

def create_supplier(session: Session, data: SupplierCreate) -> Supplier:
    if session.scalar(select(Supplier).where(Supplier.code == data.code)):
        raise Conflict(f"supplier {data.code} already exists")
    supplier = Supplier(**data.model_dump())
    session.add(supplier)
    session.commit()
    return supplier


def get_supplier(session: Session, code: str) -> Supplier:
    supplier = session.scalar(select(Supplier).where(Supplier.code == code))
    if supplier is None:
        raise NotFound(f"supplier {code} not found")
    return supplier


def list_suppliers(session: Session) -> list[Supplier]:
    return list(session.scalars(select(Supplier).order_by(Supplier.code)))


# ---------------------------------------------------------------- purchase orders

def get_po(session: Session, po_number: str) -> PurchaseOrder:
    po = session.scalar(select(PurchaseOrder).where(PurchaseOrder.po_number == po_number))
    if po is None:
        raise NotFound(f"purchase order {po_number} not found")
    return po


def list_pos(session: Session, status: str | None = None) -> list[PurchaseOrder]:
    query = select(PurchaseOrder).order_by(PurchaseOrder.id.desc())
    if status:
        query = query.where(PurchaseOrder.status == status.upper())
    return list(session.scalars(query))


def create_po(
    session: Session, clients: Clients, *, supplier_code: str, warehouse_code: str, lines: list[POLineIn], source: str = "MANUAL"
) -> PurchaseOrder:
    supplier = get_supplier(session, supplier_code)
    if not supplier.active:
        raise ValidationFailed(f"supplier {supplier_code} is inactive")
    po = PurchaseOrder(po_number=_new_po_number(), supplier_code=supplier_code, warehouse_code=warehouse_code, source=source)
    for line in lines:
        product = clients.catalog.get_product(line.sku)
        po.lines.append(PurchaseOrderLine(sku=line.sku, quantity=line.quantity, unit_cost_cents=product["standard_cost_cents"]))
    session.add(po)
    session.commit()
    return po


def create_po_from_request(session: Session, clients: Clients, data: PurchaseOrderCreate) -> PurchaseOrder:
    return create_po(session, clients, supplier_code=data.supplier_code, warehouse_code=data.warehouse_code, lines=data.lines)


def _po_payload(po: PurchaseOrder) -> dict:
    return {
        "po_number": po.po_number,
        "supplier_code": po.supplier_code,
        "warehouse_code": po.warehouse_code,
        "source": po.source,
        "lines": [{"sku": line.sku, "quantity": line.quantity} for line in po.lines],
    }


def submit_po(session: Session, po_number: str) -> PurchaseOrder:
    po = get_po(session, po_number)
    if po.status != "DRAFT":
        raise Conflict(f"cannot submit purchase order in status {po.status}")
    po.status = "SUBMITTED"
    publish_event(session, Outbox, topic="purchase_order.submitted", payload=_po_payload(po), source=SOURCE)
    session.commit()
    return po


def receive_po(session: Session, po_number: str) -> PurchaseOrder:
    po = get_po(session, po_number)
    if po.status != "SUBMITTED":
        raise Conflict(f"cannot receive purchase order in status {po.status}")
    po.status = "RECEIVED"
    publish_event(session, Outbox, topic="purchase_order.received", payload=_po_payload(po), source=SOURCE)
    session.commit()
    return po


def cancel_po(session: Session, po_number: str) -> PurchaseOrder:
    po = get_po(session, po_number)
    if po.status not in OPEN_STATUSES:
        raise Conflict(f"cannot cancel purchase order in status {po.status}")
    po.status = "CANCELLED"
    session.commit()
    return po


# ---------------------------------------------------------------- auto reorder

def has_open_po_for_sku(session: Session, sku: str) -> bool:
    query = (
        select(PurchaseOrder.id)
        .join(PurchaseOrderLine)
        .where(PurchaseOrderLine.sku == sku, PurchaseOrder.status.in_(OPEN_STATUSES))
        .limit(1)
    )
    return session.scalar(query) is not None


def auto_reorder(session: Session, clients: Clients, sku: str) -> PurchaseOrder | None:
    if not is_enabled("auto_reorder"):
        log.info("auto_reorder disabled; ignoring stock.low for %s", sku)
        return None
    if has_open_po_for_sku(session, sku):
        log.info("open purchase order already exists for %s; skipping", sku)
        return None
    policy = clients.catalog.get_reorder_policy(sku)
    supplier_code = policy.get("preferred_supplier_code")
    if not supplier_code:
        fallback = session.scalar(select(Supplier).where(Supplier.active.is_(True)).order_by(Supplier.code))
        if fallback is None:
            log.error("no active supplier available to reorder %s", sku)
            return None
        supplier_code = fallback.code
    po = create_po(
        session,
        clients,
        supplier_code=supplier_code,
        warehouse_code=DEFAULT_RECEIVING_WAREHOUSE,
        lines=[POLineIn(sku=sku, quantity=policy["reorder_qty"])],
        source="AUTO_REORDER",
    )
    if is_enabled("auto_submit_reorders"):
        po = submit_po(session, po.po_number)
    return po
