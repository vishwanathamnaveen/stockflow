"""Purchasing service: suppliers, purchase orders and automatic reorders."""
from stockflow_common.app_factory import create_service_app
from stockflow_common.events import OutboxRelay, build_event_router

from .api import router
from .database import db
from .handlers import HANDLERS
from .models import Base, Inbox, Outbox

relay = OutboxRelay(db.SessionLocal, Outbox, source="purchasing")

app = create_service_app(
    "purchasing",
    description="Suppliers and purchase orders. Reacts to stock.low with automatic reorders.",
    on_startup=[lambda: db.create_all(Base), relay.start],
    on_shutdown=[relay.stop],
)
app.include_router(router)
app.include_router(build_event_router(handlers=HANDLERS, session_dependency=db.session, inbox_model=Inbox))
