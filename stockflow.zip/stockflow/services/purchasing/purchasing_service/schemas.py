from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class SupplierCreate(BaseModel):
    code: str = Field(pattern=r"^SUP-[A-Z0-9]+$")
    name: str
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    lead_time_days: int = Field(default=7, gt=0)


class SupplierOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    code: str
    name: str
    email: str
    lead_time_days: int
    active: bool


class POLineIn(BaseModel):
    sku: str
    quantity: int = Field(gt=0)


class PurchaseOrderCreate(BaseModel):
    supplier_code: str
    warehouse_code: str
    lines: list[POLineIn] = Field(min_length=1)


class POLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    sku: str
    quantity: int
    unit_cost_cents: int


class PurchaseOrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    po_number: str
    supplier_code: str
    warehouse_code: str
    status: str
    source: str
    created_at: datetime
    lines: list[POLineOut]
