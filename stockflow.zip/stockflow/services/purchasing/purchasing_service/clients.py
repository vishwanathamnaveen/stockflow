"""Outbound REST dependencies of the purchasing service."""
from __future__ import annotations

from stockflow_common.errors import ValidationFailed
from stockflow_common.http_client import ServiceClient


class CatalogClient:
    def __init__(self) -> None:
        self._http = ServiceClient("catalog", timeout=3.0, max_retries=1)

    def get_product(self, sku: str) -> dict:
        response = self._http.get(f"/products/{sku}")
        if response.status_code == 404:
            raise ValidationFailed(f"unknown sku {sku}", details={"sku": sku})
        return response.json()

    def get_reorder_policy(self, sku: str) -> dict:
        response = self._http.get(f"/products/{sku}/reorder-policy")
        if response.status_code == 404:
            raise ValidationFailed(f"unknown sku {sku}", details={"sku": sku})
        return response.json()


class Clients:
    def __init__(self) -> None:
        self.catalog = CatalogClient()


clients = Clients()
