from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from . import domain
from .clients import clients
from .database import db
from .schemas import PurchaseOrderCreate, PurchaseOrderOut, SupplierCreate, SupplierOut

router = APIRouter()


@router.post("/suppliers", response_model=SupplierOut, status_code=201, tags=["suppliers"])
def create_supplier(data: SupplierCreate, session: Session = Depends(db.session)):
    return domain.create_supplier(session, data)


@router.get("/suppliers", response_model=list[SupplierOut], tags=["suppliers"])
def list_suppliers(session: Session = Depends(db.session)):
    return domain.list_suppliers(session)


@router.get("/suppliers/{code}", response_model=SupplierOut, tags=["suppliers"])
def get_supplier(code: str, session: Session = Depends(db.session)):
    return domain.get_supplier(session, code)


@router.post("/purchase-orders", response_model=PurchaseOrderOut, status_code=201, tags=["purchase-orders"])
def create_po(data: PurchaseOrderCreate, session: Session = Depends(db.session)):
    return domain.create_po_from_request(session, clients, data)


@router.get("/purchase-orders", response_model=list[PurchaseOrderOut], tags=["purchase-orders"])
def list_pos(status: str | None = None, session: Session = Depends(db.session)):
    return domain.list_pos(session, status)


@router.get("/purchase-orders/{po_number}", response_model=PurchaseOrderOut, tags=["purchase-orders"])
def get_po(po_number: str, session: Session = Depends(db.session)):
    return domain.get_po(session, po_number)


@router.post("/purchase-orders/{po_number}/submit", response_model=PurchaseOrderOut, tags=["purchase-orders"])
def submit_po(po_number: str, session: Session = Depends(db.session)):
    return domain.submit_po(session, po_number)


@router.post("/purchase-orders/{po_number}/receive", response_model=PurchaseOrderOut, tags=["purchase-orders"])
def receive_po(po_number: str, session: Session = Depends(db.session)):
    return domain.receive_po(session, po_number)


@router.post("/purchase-orders/{po_number}/cancel", response_model=PurchaseOrderOut, tags=["purchase-orders"])
def cancel_po(po_number: str, session: Session = Depends(db.session)):
    return domain.cancel_po(session, po_number)
