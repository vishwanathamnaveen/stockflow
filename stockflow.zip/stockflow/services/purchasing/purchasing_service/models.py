from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from stockflow_common.events import InboxMixin, OutboxMixin, utcnow


class Base(DeclarativeBase):
    pass


class Supplier(Base):
    __tablename__ = "suppliers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    email: Mapped[str] = mapped_column(String(200))
    lead_time_days: Mapped[int] = mapped_column(Integer, default=7)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    po_number: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    supplier_code: Mapped[str] = mapped_column(ForeignKey("suppliers.code"), index=True)
    warehouse_code: Mapped[str] = mapped_column(String(20))
    # DRAFT -> SUBMITTED -> RECEIVED ; DRAFT|SUBMITTED -> CANCELLED
    status: Mapped[str] = mapped_column(String(20), default="DRAFT", index=True)
    source: Mapped[str] = mapped_column(String(20), default="MANUAL")  # MANUAL|AUTO_REORDER
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    lines: Mapped[list["PurchaseOrderLine"]] = relationship(back_populates="purchase_order", cascade="all, delete-orphan")


class PurchaseOrderLine(Base):
    __tablename__ = "purchase_order_lines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    purchase_order_id: Mapped[int] = mapped_column(ForeignKey("purchase_orders.id"), index=True)
    sku: Mapped[str] = mapped_column(String(40), index=True)
    quantity: Mapped[int] = mapped_column(Integer)
    unit_cost_cents: Mapped[int] = mapped_column(Integer)

    purchase_order: Mapped[PurchaseOrder] = relationship(back_populates="lines")


class Outbox(OutboxMixin, Base):
    __tablename__ = "outbox"


class Inbox(InboxMixin, Base):
    __tablename__ = "inbox"
