"""Event consumers for the purchasing service."""
from __future__ import annotations

from sqlalchemy.orm import Session

from . import domain
from .clients import clients


def on_stock_low(session: Session, payload: dict) -> None:
    domain.auto_reorder(session, clients, payload["sku"])


HANDLERS = {"stock.low": on_stock_low}
