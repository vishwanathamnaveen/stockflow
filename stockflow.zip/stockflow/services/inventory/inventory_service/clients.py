"""Outbound REST dependencies of the inventory service."""
from __future__ import annotations

from stockflow_common.errors import NotFound, ValidationFailed
from stockflow_common.http_client import ServiceClient


class CatalogClient:
    def __init__(self) -> None:
        self._http = ServiceClient("catalog", timeout=3.0, max_retries=1)

    def get_product(self, sku: str) -> dict:
        response = self._http.get(f"/products/{sku}")
        if response.status_code == 404:
            raise ValidationFailed(f"unknown sku {sku}", details={"sku": sku})
        return response.json()

    def get_reorder_policy(self, sku: str) -> dict:
        response = self._http.get(f"/products/{sku}/reorder-policy")
        if response.status_code == 404:
            raise NotFound(f"no reorder policy for {sku}")
        return response.json()


class WarehouseClient:
    def __init__(self) -> None:
        self._http = ServiceClient("warehouse", timeout=3.0, max_retries=1)

    def ensure_active(self, code: str) -> dict:
        response = self._http.get(f"/warehouses/{code}")
        if response.status_code == 404:
            raise ValidationFailed(f"unknown warehouse {code}", details={"warehouse_code": code})
        warehouse = response.json()
        if not warehouse.get("active", False):
            raise ValidationFailed(f"warehouse {code} is inactive", details={"warehouse_code": code})
        return warehouse


class Clients:
    """Holder so tests can swap in fakes: `clients.catalog = FakeCatalog()`."""

    def __init__(self) -> None:
        self.catalog = CatalogClient()
        self.warehouse = WarehouseClient()


clients = Clients()
