"""Inventory service: stock levels, reservations and the movement ledger."""
from stockflow_common.app_factory import create_service_app
from stockflow_common.events import OutboxRelay, build_event_router

from .api import router
from .database import db
from .handlers import HANDLERS
from .models import Base, Inbox, Outbox

relay = OutboxRelay(db.SessionLocal, Outbox, source="inventory")

app = create_service_app(
    "inventory",
    description="Stock levels per warehouse, order reservations and an append-only movement ledger.",
    on_startup=[lambda: db.create_all(Base), relay.start],
    on_shutdown=[relay.stop],
)
app.include_router(router)
app.include_router(build_event_router(handlers=HANDLERS, session_dependency=db.session, inbox_model=Inbox))
