from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ReservationLine(BaseModel):
    sku: str
    quantity: int = Field(gt=0)


class ReservationRequest(BaseModel):
    order_id: str
    lines: list[ReservationLine] = Field(min_length=1)


class ReservationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    order_id: str
    sku: str
    warehouse_code: str
    quantity: int
    status: str


class ReceiptLine(BaseModel):
    sku: str
    quantity: int = Field(gt=0)


class ReceiptRequest(BaseModel):
    warehouse_code: str
    reference: str
    lines: list[ReceiptLine] = Field(min_length=1)


class AdjustmentRequest(BaseModel):
    sku: str
    warehouse_code: str
    delta: int
    reason: str = Field(min_length=3)


class StockLevelOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    sku: str
    warehouse_code: str
    on_hand: int
    reserved: int
    available: int


class StockSummary(BaseModel):
    sku: str
    on_hand: int
    reserved: int
    available: int
    levels: list[StockLevelOut]


class MovementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    sku: str
    warehouse_code: str
    movement_type: str
    quantity: int
    reference: str
    created_at: datetime
