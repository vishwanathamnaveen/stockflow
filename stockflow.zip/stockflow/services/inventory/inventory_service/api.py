from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import domain
from .clients import clients
from .database import db
from .models import StockLevel, StockMovement
from .schemas import (
    AdjustmentRequest,
    MovementOut,
    ReceiptRequest,
    ReservationOut,
    ReservationRequest,
    StockLevelOut,
    StockSummary,
)

router = APIRouter()


@router.get("/stock/{sku}", response_model=StockSummary, tags=["stock"])
def stock_for_sku(sku: str, session: Session = Depends(db.session)):
    levels = domain.levels_for_sku(session, sku)
    return StockSummary(
        sku=sku,
        on_hand=sum(level.on_hand for level in levels),
        reserved=sum(level.reserved for level in levels),
        available=sum(level.available for level in levels),
        levels=[StockLevelOut.model_validate(level) for level in levels],
    )


@router.get("/stock", response_model=list[StockLevelOut], tags=["stock"])
def list_stock(warehouse_code: str | None = None, session: Session = Depends(db.session)):
    query = select(StockLevel).order_by(StockLevel.sku, StockLevel.warehouse_code)
    if warehouse_code:
        query = query.where(StockLevel.warehouse_code == warehouse_code)
    return session.scalars(query).all()


@router.post("/receipts", response_model=list[StockLevelOut], status_code=201, tags=["stock"])
def receive(request: ReceiptRequest, session: Session = Depends(db.session)):
    return domain.receive_stock(
        session,
        clients,
        warehouse_code=request.warehouse_code,
        reference=request.reference,
        lines=[(line.sku, line.quantity) for line in request.lines],
    )


@router.post("/adjustments", response_model=StockLevelOut, tags=["stock"])
def adjust(request: AdjustmentRequest, session: Session = Depends(db.session)):
    return domain.adjust_stock(
        session, clients, sku=request.sku, warehouse_code=request.warehouse_code, delta=request.delta, reason=request.reason
    )


@router.post("/reservations", response_model=list[ReservationOut], status_code=201, tags=["reservations"])
def reserve(request: ReservationRequest, session: Session = Depends(db.session)):
    return domain.reserve(session, clients, order_id=request.order_id, lines=request.lines)


@router.get("/reservations/{order_id}", response_model=list[ReservationOut], tags=["reservations"])
def get_reservation(order_id: str, session: Session = Depends(db.session)):
    return domain.get_reservations(session, order_id)


@router.post("/reservations/{order_id}/release", response_model=list[ReservationOut], tags=["reservations"])
def release(order_id: str, session: Session = Depends(db.session)):
    return domain.release(session, order_id=order_id)


@router.post("/reservations/{order_id}/commit", response_model=list[ReservationOut], tags=["reservations"])
def commit(order_id: str, session: Session = Depends(db.session)):
    return domain.commit(session, order_id=order_id)


@router.get("/movements", response_model=list[MovementOut], tags=["ledger"])
def movements(sku: str | None = None, limit: int = 200, session: Session = Depends(db.session)):
    query = select(StockMovement).order_by(StockMovement.id.desc()).limit(limit)
    if sku:
        query = query.where(StockMovement.sku == sku)
    return session.scalars(query).all()
