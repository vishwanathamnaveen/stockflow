"""Event consumers for the inventory service."""
from __future__ import annotations

from sqlalchemy.orm import Session

from . import domain
from .clients import clients


def on_purchase_order_received(session: Session, payload: dict) -> None:
    domain.receive_stock(
        session,
        clients,
        warehouse_code=payload["warehouse_code"],
        reference=payload["po_number"],
        lines=[(line["sku"], line["quantity"]) for line in payload["lines"]],
    )


def on_product_updated(session: Session, payload: dict) -> None:
    if payload.get("policy_changed"):
        domain.invalidate_policy(session, payload["sku"])


HANDLERS = {
    "purchase_order.received": on_purchase_order_received,
    "product.updated": on_product_updated,
}
