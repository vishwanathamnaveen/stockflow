from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Integer, String, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from stockflow_common.events import InboxMixin, OutboxMixin, utcnow


class Base(DeclarativeBase):
    pass


class StockLevel(Base):
    __tablename__ = "stock_levels"
    __table_args__ = (UniqueConstraint("sku", "warehouse_code", name="uq_stock_sku_warehouse"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sku: Mapped[str] = mapped_column(String(40), index=True)
    warehouse_code: Mapped[str] = mapped_column(String(20), index=True)
    on_hand: Mapped[int] = mapped_column(Integer, default=0)
    reserved: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    @property
    def available(self) -> int:
        return self.on_hand - self.reserved


class Reservation(Base):
    __tablename__ = "reservations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    order_id: Mapped[str] = mapped_column(String(40), index=True)
    sku: Mapped[str] = mapped_column(String(40))
    warehouse_code: Mapped[str] = mapped_column(String(20))
    quantity: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default="ACTIVE")  # ACTIVE|RELEASED|COMMITTED
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class StockMovement(Base):
    """Append-only ledger. Every change to on_hand or reserved writes one row."""

    __tablename__ = "stock_movements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sku: Mapped[str] = mapped_column(String(40), index=True)
    warehouse_code: Mapped[str] = mapped_column(String(20))
    movement_type: Mapped[str] = mapped_column(String(20))  # RECEIPT|RESERVATION|RELEASE|SHIPMENT|ADJUSTMENT
    quantity: Mapped[int] = mapped_column(Integer)
    reference: Mapped[str] = mapped_column(String(60))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ReorderPolicyCache(Base):
    """Local copy of catalog reorder policy. Invalidated by product.updated events."""

    __tablename__ = "reorder_policy_cache"

    sku: Mapped[str] = mapped_column(String(40), primary_key=True)
    reorder_point: Mapped[int] = mapped_column(Integer)
    reorder_qty: Mapped[int] = mapped_column(Integer)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Outbox(OutboxMixin, Base):
    __tablename__ = "outbox"


class Inbox(InboxMixin, Base):
    __tablename__ = "inbox"
