"""Inventory business logic.

Business rules (docs/business-rules.md):
  BR-010 Reservations are all-or-nothing per order.
  BR-011 Available stock = on_hand - reserved.
  BR-012 Allocation takes stock from the warehouse with the most available first.
  BR-013 stock.low is published when total available <= reorder_point.
  BR-014 Reserving the same order twice returns the existing reservation (idempotent).
"""
from __future__ import annotations

import logging
import time

from sqlalchemy import select
from sqlalchemy.orm import Session

from stockflow_common.errors import Conflict, NotFound, ValidationFailed
from stockflow_common.events import publish_event
from stockflow_common.flags import flag_value

from .clients import Clients
from .models import Outbox, ReorderPolicyCache, Reservation, StockLevel, StockMovement
from .schemas import ReservationLine

log = logging.getLogger(__name__)
SOURCE = "inventory"


# ---------------------------------------------------------------- queries

def levels_for_sku(session: Session, sku: str) -> list[StockLevel]:
    return list(session.scalars(select(StockLevel).where(StockLevel.sku == sku).order_by(StockLevel.warehouse_code)))


def total_available(session: Session, sku: str) -> int:
    return sum(level.available for level in levels_for_sku(session, sku))


def _get_or_create_level(session: Session, sku: str, warehouse_code: str) -> StockLevel:
    level = session.scalar(
        select(StockLevel).where(StockLevel.sku == sku, StockLevel.warehouse_code == warehouse_code)
    )
    if level is None:
        level = StockLevel(sku=sku, warehouse_code=warehouse_code, on_hand=0, reserved=0)
        session.add(level)
        session.flush()
    return level


def _record(session: Session, sku: str, warehouse_code: str, movement_type: str, quantity: int, reference: str) -> None:
    session.add(
        StockMovement(sku=sku, warehouse_code=warehouse_code, movement_type=movement_type, quantity=quantity, reference=reference)
    )


# ---------------------------------------------------------------- reorder policy

def get_reorder_policy(session: Session, clients: Clients, sku: str) -> ReorderPolicyCache:
    cached = session.get(ReorderPolicyCache, sku)
    if cached is not None:
        return cached
    policy = clients.catalog.get_reorder_policy(sku)
    cached = ReorderPolicyCache(sku=sku, reorder_point=policy["reorder_point"], reorder_qty=policy["reorder_qty"])
    session.add(cached)
    session.flush()
    return cached


def invalidate_policy(session: Session, sku: str) -> None:
    cached = session.get(ReorderPolicyCache, sku)
    if cached is not None:
        session.delete(cached)


def check_low_stock(session: Session, clients: Clients, sku: str) -> bool:
    policy = get_reorder_policy(session, clients, sku)
    available = total_available(session, sku)
    if available <= policy.reorder_point:
        publish_event(
            session,
            Outbox,
            topic="stock.low",
            payload={"sku": sku, "available": available, "reorder_point": policy.reorder_point, "reorder_qty": policy.reorder_qty},
            source=SOURCE,
        )
        return True
    return False


# ---------------------------------------------------------------- receipts & adjustments

def receive_stock(
    session: Session, clients: Clients, *, warehouse_code: str, reference: str, lines: list[tuple[str, int]]
) -> list[StockLevel]:
    clients.warehouse.ensure_active(warehouse_code)
    touched = []
    for sku, quantity in lines:
        clients.catalog.get_product(sku)
        level = _get_or_create_level(session, sku, warehouse_code)
        level.on_hand += quantity
        _record(session, sku, warehouse_code, "RECEIPT", quantity, reference)
        touched.append(level)
    session.commit()
    return touched


def adjust_stock(session: Session, clients: Clients, *, sku: str, warehouse_code: str, delta: int, reason: str) -> StockLevel:
    level = _get_or_create_level(session, sku, warehouse_code)
    if level.on_hand + delta < level.reserved:
        raise Conflict(
            "adjustment would drop on_hand below reserved quantity",
            details={"on_hand": level.on_hand, "reserved": level.reserved, "delta": delta},
        )
    level.on_hand += delta
    _record(session, sku, warehouse_code, "ADJUSTMENT", delta, reason)
    if delta < 0:
        check_low_stock(session, clients, sku)
    session.commit()
    return level


# ---------------------------------------------------------------- reservations

def get_reservations(session: Session, order_id: str) -> list[Reservation]:
    return list(session.scalars(select(Reservation).where(Reservation.order_id == order_id).order_by(Reservation.id)))


def _plan_allocation(session: Session, line: ReservationLine) -> list[tuple[StockLevel, int]]:
    levels = sorted(levels_for_sku(session, line.sku), key=lambda lvl: lvl.available, reverse=True)
    remaining = line.quantity
    plan: list[tuple[StockLevel, int]] = []
    for level in levels:
        if remaining == 0:
            break
        take = min(level.available, remaining)
        if take > 0:
            plan.append((level, take))
            remaining -= take
    if remaining > 0:
        raise Conflict(
            f"insufficient stock for {line.sku}",
            details={"sku": line.sku, "requested": line.quantity, "available": line.quantity - remaining},
        )
    return plan


def reserve(session: Session, clients: Clients, *, order_id: str, lines: list[ReservationLine]) -> list[Reservation]:
    delay_ms = flag_value("inventory_reservation_delay_ms", 0)
    if delay_ms:
        log.warning("fault injection: delaying reservation for %s by %sms", order_id, delay_ms)
        time.sleep(int(delay_ms) / 1000)

    existing = [r for r in get_reservations(session, order_id) if r.status == "ACTIVE"]
    if existing:
        return existing

    # Plan every line before writing anything (all-or-nothing, BR-010).
    plans = [(line, _plan_allocation(session, line)) for line in lines]

    created: list[Reservation] = []
    for line, plan in plans:
        for level, quantity in plan:
            level.reserved += quantity
            _record(session, line.sku, level.warehouse_code, "RESERVATION", quantity, order_id)
            reservation = Reservation(order_id=order_id, sku=line.sku, warehouse_code=level.warehouse_code, quantity=quantity)
            session.add(reservation)
            created.append(reservation)

    publish_event(
        session,
        Outbox,
        topic="stock.reserved",
        payload={"order_id": order_id, "lines": [line.model_dump() for line in lines]},
        source=SOURCE,
    )
    for sku in {line.sku for line in lines}:
        check_low_stock(session, clients, sku)
    session.commit()
    return created


def _active_or_fail(session: Session, order_id: str) -> list[Reservation]:
    reservations = get_reservations(session, order_id)
    if not reservations:
        raise NotFound(f"no reservation for order {order_id}")
    active = [r for r in reservations if r.status == "ACTIVE"]
    if not active:
        raise Conflict(f"reservation for {order_id} is already {reservations[0].status}")
    return active


def release(session: Session, *, order_id: str) -> list[Reservation]:
    active = _active_or_fail(session, order_id)
    for reservation in active:
        level = _get_or_create_level(session, reservation.sku, reservation.warehouse_code)
        level.reserved -= reservation.quantity
        reservation.status = "RELEASED"
        _record(session, reservation.sku, reservation.warehouse_code, "RELEASE", reservation.quantity, order_id)
    publish_event(session, Outbox, topic="stock.released", payload={"order_id": order_id}, source=SOURCE)
    session.commit()
    return active


def commit(session: Session, *, order_id: str) -> list[Reservation]:
    """Goods leave the warehouse: reduce on_hand and reserved together."""
    active = _active_or_fail(session, order_id)
    for reservation in active:
        level = _get_or_create_level(session, reservation.sku, reservation.warehouse_code)
        if level.on_hand < reservation.quantity:
            raise ValidationFailed("on_hand lower than reserved quantity; ledger is inconsistent")
        level.on_hand -= reservation.quantity
        level.reserved -= reservation.quantity
        reservation.status = "COMMITTED"
        _record(session, reservation.sku, reservation.warehouse_code, "SHIPMENT", -reservation.quantity, order_id)
    session.commit()
    return active
