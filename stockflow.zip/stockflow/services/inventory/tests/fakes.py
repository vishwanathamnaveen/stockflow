from stockflow_common.errors import ValidationFailed


class FakeCatalog:
    def __init__(self, reorder_point: int = 5, reorder_qty: int = 20) -> None:
        self.reorder_point = reorder_point
        self.reorder_qty = reorder_qty
        self.policy_calls = 0

    def get_product(self, sku: str) -> dict:
        if sku.startswith("UNKNOWN"):
            raise ValidationFailed(f"unknown sku {sku}")
        return {"sku": sku, "active": True}

    def get_reorder_policy(self, sku: str) -> dict:
        self.policy_calls += 1
        return {"sku": sku, "reorder_point": self.reorder_point, "reorder_qty": self.reorder_qty}


class FakeWarehouse:
    def ensure_active(self, code: str) -> dict:
        if code == "BAD-01":
            raise ValidationFailed(f"unknown warehouse {code}")
        return {"code": code, "active": True}
