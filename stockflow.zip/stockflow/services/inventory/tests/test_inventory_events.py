import pytest

from inventory_service.clients import clients

from fakes import FakeCatalog, FakeWarehouse


@pytest.fixture(autouse=True)
def fake_clients():
    clients.catalog = FakeCatalog()
    clients.warehouse = FakeWarehouse()
    yield clients


def envelope(event_id, topic, payload):
    return {"event_id": event_id, "topic": topic, "source": "test", "payload": payload}


def test_purchase_order_received_adds_stock(client):
    payload = {"po_number": "PO-1", "warehouse_code": "HYD-01", "lines": [{"sku": "SKU-A", "quantity": 40}]}
    assert client.post("/events/receive", json=envelope("e1", "purchase_order.received", payload)).json()["status"] == "processed"
    assert client.get("/stock/SKU-A").json()["on_hand"] == 40


def test_duplicate_event_is_processed_once(client):
    payload = {"po_number": "PO-1", "warehouse_code": "HYD-01", "lines": [{"sku": "SKU-A", "quantity": 40}]}
    client.post("/events/receive", json=envelope("e1", "purchase_order.received", payload))
    assert client.post("/events/receive", json=envelope("e1", "purchase_order.received", payload)).json()["status"] == "duplicate"
    assert client.get("/stock/SKU-A").json()["on_hand"] == 40


def test_policy_change_invalidates_cached_policy(client, fake_clients):
    client.post("/receipts", json={"warehouse_code": "HYD-01", "reference": "T", "lines": [{"sku": "SKU-A", "quantity": 50}]})
    client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 1}]})
    client.post("/reservations", json={"order_id": "SO-2", "lines": [{"sku": "SKU-A", "quantity": 1}]})
    assert fake_clients.catalog.policy_calls == 1  # cached after first lookup
    client.post("/events/receive", json=envelope("e2", "product.updated", {"sku": "SKU-A", "changed_fields": ["reorder_point"], "policy_changed": True}))
    client.post("/reservations", json={"order_id": "SO-3", "lines": [{"sku": "SKU-A", "quantity": 1}]})
    assert fake_clients.catalog.policy_calls == 2


def test_unknown_topic_rejected(client):
    assert client.post("/events/receive", json=envelope("e3", "nope.topic", {})).status_code == 400
