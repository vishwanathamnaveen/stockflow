import json

import pytest

from inventory_service.clients import clients
from inventory_service.models import Outbox

from fakes import FakeCatalog, FakeWarehouse


@pytest.fixture(autouse=True)
def fake_clients():
    clients.catalog = FakeCatalog(reorder_point=5)
    clients.warehouse = FakeWarehouse()
    yield clients


def receive(client, sku, warehouse, qty):
    response = client.post("/receipts", json={"warehouse_code": warehouse, "reference": "T", "lines": [{"sku": sku, "quantity": qty}]})
    assert response.status_code == 201, response.text


def topics(session):
    return [row.topic for row in session.query(Outbox).order_by(Outbox.id)]


def test_receipt_increases_on_hand(client):
    receive(client, "SKU-A", "HYD-01", 10)
    assert client.get("/stock/SKU-A").json()["on_hand"] == 10


def test_receipt_rejects_unknown_warehouse(client):
    response = client.post("/receipts", json={"warehouse_code": "BAD-01", "reference": "T", "lines": [{"sku": "SKU-A", "quantity": 1}]})
    assert response.status_code == 422


def test_available_excludes_reserved_stock(client):
    receive(client, "SKU-A", "HYD-01", 10)
    client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 4}]})
    stock = client.get("/stock/SKU-A").json()
    assert (stock["on_hand"], stock["reserved"], stock["available"]) == (10, 4, 6)


def test_second_order_cannot_reserve_already_reserved_stock(client):
    receive(client, "SKU-A", "HYD-01", 10)
    assert client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 8}]}).status_code == 201
    response = client.post("/reservations", json={"order_id": "SO-2", "lines": [{"sku": "SKU-A", "quantity": 5}]})
    assert response.status_code == 409
    assert response.json()["details"]["available"] == 2


def test_reservation_splits_across_warehouses_largest_first(client):
    receive(client, "SKU-A", "HYD-01", 6)
    receive(client, "SKU-A", "BLR-01", 10)
    reservations = client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 13}]}).json()
    assert [(r["warehouse_code"], r["quantity"]) for r in reservations] == [("BLR-01", 10), ("HYD-01", 3)]


def test_reservation_is_all_or_nothing(client):
    receive(client, "SKU-A", "HYD-01", 10)
    receive(client, "SKU-B", "HYD-01", 1)
    response = client.post(
        "/reservations",
        json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 5}, {"sku": "SKU-B", "quantity": 2}]},
    )
    assert response.status_code == 409
    assert client.get("/stock/SKU-A").json()["reserved"] == 0


def test_reservation_is_idempotent_per_order(client):
    receive(client, "SKU-A", "HYD-01", 10)
    body = {"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 3}]}
    client.post("/reservations", json=body)
    client.post("/reservations", json=body)
    assert client.get("/stock/SKU-A").json()["reserved"] == 3


def test_release_returns_stock(client, session):
    receive(client, "SKU-A", "HYD-01", 10)
    client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 3}]})
    assert client.post("/reservations/SO-1/release").status_code == 200
    assert client.get("/stock/SKU-A").json()["available"] == 10
    assert "stock.released" in topics(session)
    assert client.post("/reservations/SO-1/release").status_code == 409


def test_commit_reduces_on_hand_and_reserved(client):
    receive(client, "SKU-A", "HYD-01", 10)
    client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 3}]})
    client.post("/reservations/SO-1/commit")
    stock = client.get("/stock/SKU-A").json()
    assert (stock["on_hand"], stock["reserved"]) == (7, 0)
    assert [m["movement_type"] for m in client.get("/movements", params={"sku": "SKU-A"}).json()] == ["SHIPMENT", "RESERVATION", "RECEIPT"]


def test_low_stock_event_when_available_hits_reorder_point(client, session):
    receive(client, "SKU-A", "HYD-01", 10)
    client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 5}]})
    low = [json.loads(r.payload) for r in session.query(Outbox).filter_by(topic="stock.low")]
    assert low == [{"sku": "SKU-A", "available": 5, "reorder_point": 5, "reorder_qty": 20}]


def test_no_low_stock_event_above_reorder_point(client, session):
    receive(client, "SKU-A", "HYD-01", 10)
    client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 2}]})
    assert "stock.low" not in topics(session)


def test_negative_adjustment_cannot_undercut_reservations(client):
    receive(client, "SKU-A", "HYD-01", 10)
    client.post("/reservations", json={"order_id": "SO-1", "lines": [{"sku": "SKU-A", "quantity": 8}]})
    response = client.post("/adjustments", json={"sku": "SKU-A", "warehouse_code": "HYD-01", "delta": -5, "reason": "damaged"})
    assert response.status_code == 409
