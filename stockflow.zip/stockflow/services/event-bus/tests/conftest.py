import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "libs" / "common"), str(ROOT / "services" / "event-bus")]

from stockflow_common.testing import prepare_test_environment, reset_flags  # noqa: E402

prepare_test_environment("event-bus")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from event_bus_service.database import db  # noqa: E402
from event_bus_service.main import app  # noqa: E402
from event_bus_service.models import Base  # noqa: E402


@pytest.fixture(autouse=True)
def _fresh_state():
    db.reset(Base)
    reset_flags()
    yield


@pytest.fixture
def client():
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def session():
    with db.SessionLocal() as s:
        yield s
