import httpx

from event_bus_service import dispatcher
from event_bus_service.models import Delivery


def publish(client, event_id="e1", topic="stock.low"):
    return client.post("/publish", json={"event_id": event_id, "topic": topic, "source": "inventory", "payload": {"sku": "A"}})


def test_publish_fans_out_to_subscribers(client):
    body = publish(client).json()
    assert sorted(body["subscribers"]) == ["notification", "purchasing"]
    assert len(client.get("/deliveries").json()) == 2


def test_duplicate_publish_is_ignored(client):
    publish(client)
    assert publish(client).json()["duplicate"] is True
    assert len(client.get("/deliveries").json()) == 2


def test_dispatch_marks_delivered(client, session):
    publish(client)
    ok = httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(200, json={})))
    assert dispatcher.deliver_pending(session, ok) == 2
    assert {d.status for d in session.query(Delivery)} == {"DELIVERED"}


def test_failed_delivery_backs_off_then_dead_letters(client, session, monkeypatch):
    monkeypatch.setattr(dispatcher, "MAX_ATTEMPTS", 2)
    monkeypatch.setattr(dispatcher, "BASE_BACKOFF_SECONDS", 0)
    publish(client, topic="order.confirmed")
    failing = httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(500)))
    dispatcher.deliver_pending(session, failing)
    assert session.query(Delivery).one().status == "PENDING"
    dispatcher.deliver_pending(session, failing)
    delivery = session.query(Delivery).one()
    assert (delivery.status, delivery.attempts) == ("DEAD", 2)
    assert client.post(f"/deliveries/{delivery.id}/redeliver").json()["status"] == "PENDING"


def test_backoff_is_exponential():
    assert [dispatcher.backoff_for(n).total_seconds() for n in (1, 2, 3)] == [
        dispatcher.BASE_BACKOFF_SECONDS * 1,
        dispatcher.BASE_BACKOFF_SECONDS * 2,
        dispatcher.BASE_BACKOFF_SECONDS * 4,
    ]
