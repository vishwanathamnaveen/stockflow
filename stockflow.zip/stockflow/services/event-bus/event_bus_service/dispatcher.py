"""Delivers pending events to subscribers with exponential backoff.
After MAX_ATTEMPTS failures a delivery is marked DEAD (dead letter)."""
from __future__ import annotations

import json
import logging
import threading
from datetime import UTC, datetime, timedelta

import httpx
from opentelemetry import context as otel_context
from opentelemetry import propagate
from sqlalchemy import select
from sqlalchemy.orm import Session

from stockflow_common.events import utcnow
from stockflow_common.settings import env_bool, env_float, env_int, service_url

from .models import Delivery, Event

log = logging.getLogger(__name__)

MAX_ATTEMPTS = env_int("EVENT_BUS_MAX_ATTEMPTS", 5)
BASE_BACKOFF_SECONDS = env_float("EVENT_BUS_BASE_BACKOFF_SECONDS", 1.0)


def backoff_for(attempts: int) -> timedelta:
    return timedelta(seconds=BASE_BACKOFF_SECONDS * (2 ** (attempts - 1)))


def _as_aware(value: datetime) -> datetime:
    return value if value.tzinfo else value.replace(tzinfo=UTC)


def deliver_pending(session: Session, client: httpx.Client, limit: int = 50) -> int:
    now = utcnow()
    deliveries = session.scalars(
        select(Delivery).where(Delivery.status == "PENDING").order_by(Delivery.id).limit(limit)
    ).all()
    delivered = 0
    for delivery in deliveries:
        if _as_aware(delivery.next_attempt_at) > now:
            continue
        event = session.get(Event, delivery.event_id)
        headers = json.loads(event.headers or "{}")
        token = otel_context.attach(propagate.extract(headers))
        try:
            response = client.post(
                f"{service_url(delivery.subscriber)}/events/receive",
                json={
                    "event_id": event.event_id,
                    "topic": event.topic,
                    "source": event.source,
                    "payload": json.loads(event.payload),
                    "published_at": event.received_at.isoformat(),
                },
            )
            response.raise_for_status()
            delivery.status = "DELIVERED"
            delivery.delivered_at = utcnow()
            delivered += 1
        except Exception as exc:
            delivery.attempts += 1
            delivery.last_error = str(exc)[:500]
            if delivery.attempts >= MAX_ATTEMPTS:
                delivery.status = "DEAD"
                log.error("dead-lettered %s -> %s after %d attempts", event.topic, delivery.subscriber, delivery.attempts)
            else:
                delivery.next_attempt_at = utcnow() + backoff_for(delivery.attempts)
                log.warning("delivery %s -> %s failed (attempt %d): %s", event.topic, delivery.subscriber, delivery.attempts, exc)
        finally:
            otel_context.detach(token)
    session.commit()
    return delivered


class Dispatcher:
    def __init__(self, session_factory, interval_seconds: float = 0.3) -> None:
        self.session_factory = session_factory
        self.interval_seconds = interval_seconds
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._client = httpx.Client(timeout=10.0)

    def start(self) -> None:
        if not env_bool("STOCKFLOW_RELAY", True):
            return
        self._thread = threading.Thread(target=self._run, name="event-bus-dispatcher", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                with self.session_factory() as session:
                    deliver_pending(session, self._client)
            except Exception:  # pragma: no cover
                log.exception("dispatcher iteration failed")
            self._stop.wait(self.interval_seconds)
