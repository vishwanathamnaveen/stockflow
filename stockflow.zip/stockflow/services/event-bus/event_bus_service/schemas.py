from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict


class PublishRequest(BaseModel):
    event_id: str
    topic: str
    source: str
    payload: dict[str, Any]
    headers: dict[str, str] = {}


class PublishResponse(BaseModel):
    event_id: str
    subscribers: list[str]
    duplicate: bool = False


class DeliveryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    event_id: str
    subscriber: str
    status: str
    attempts: int
    last_error: str | None
    delivered_at: datetime | None


class EventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    event_id: str
    topic: str
    source: str
    received_at: datetime
