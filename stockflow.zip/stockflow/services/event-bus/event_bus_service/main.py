"""Event bus: durable pub/sub over HTTP backed by SQLite (see ADR-002)."""
from stockflow_common.app_factory import create_service_app

from .api import router
from .database import db
from .dispatcher import Dispatcher
from .models import Base

dispatcher = Dispatcher(db.SessionLocal)

app = create_service_app(
    "event-bus",
    description="Lightweight durable pub/sub. Stores events in SQLite and pushes them to subscribers over HTTP.",
    on_startup=[lambda: db.create_all(Base), dispatcher.start],
    on_shutdown=[dispatcher.stop],
)
app.include_router(router)
