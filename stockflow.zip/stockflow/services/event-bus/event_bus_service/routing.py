"""Topic -> subscriber routing, loaded from config/subscriptions.yaml."""
from __future__ import annotations

import yaml

from stockflow_common.settings import CONFIG_DIR


def load_subscriptions() -> dict[str, list[str]]:
    with open(CONFIG_DIR / "subscriptions.yaml", encoding="utf-8") as fh:
        return yaml.safe_load(fh).get("subscriptions", {}) or {}
