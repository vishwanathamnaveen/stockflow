from __future__ import annotations

import json

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from stockflow_common.errors import NotFound

from .database import db
from .models import Delivery, Event
from .routing import load_subscriptions
from .schemas import DeliveryOut, EventOut, PublishRequest, PublishResponse

router = APIRouter()


@router.post("/publish", response_model=PublishResponse, status_code=202, tags=["bus"])
def publish(request: PublishRequest, session: Session = Depends(db.session)) -> PublishResponse:
    subscribers = load_subscriptions().get(request.topic, [])
    if session.get(Event, request.event_id) is not None:
        return PublishResponse(event_id=request.event_id, subscribers=subscribers, duplicate=True)
    session.add(
        Event(
            event_id=request.event_id,
            topic=request.topic,
            source=request.source,
            payload=json.dumps(request.payload),
            headers=json.dumps(request.headers),
        )
    )
    session.flush()
    for subscriber in subscribers:
        session.add(Delivery(event_id=request.event_id, subscriber=subscriber))
    session.commit()
    return PublishResponse(event_id=request.event_id, subscribers=subscribers)


@router.get("/subscriptions", tags=["bus"])
def subscriptions() -> dict:
    return load_subscriptions()


@router.get("/events", response_model=list[EventOut], tags=["bus"])
def list_events(topic: str | None = None, limit: int = 100, session: Session = Depends(db.session)):
    query = select(Event).order_by(Event.received_at.desc()).limit(limit)
    if topic:
        query = query.where(Event.topic == topic)
    return session.scalars(query).all()


@router.get("/deliveries", response_model=list[DeliveryOut], tags=["bus"])
def list_deliveries(status: str | None = None, limit: int = 100, session: Session = Depends(db.session)):
    query = select(Delivery).order_by(Delivery.id.desc()).limit(limit)
    if status:
        query = query.where(Delivery.status == status.upper())
    return session.scalars(query).all()


@router.post("/deliveries/{delivery_id}/redeliver", response_model=DeliveryOut, tags=["bus"])
def redeliver(delivery_id: int, session: Session = Depends(db.session)):
    delivery = session.get(Delivery, delivery_id)
    if delivery is None:
        raise NotFound(f"delivery {delivery_id} not found")
    delivery.status = "PENDING"
    delivery.attempts = 0
    session.commit()
    return delivery
