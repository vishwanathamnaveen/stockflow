from __future__ import annotations

import uuid

import httpx
from fastapi import APIRouter, Request, Response

from stockflow_common.errors import DownstreamUnavailable, NotFound
from stockflow_common.settings import service_url

from .routes import PATH_REWRITES, ROUTES

router = APIRouter()
_client = httpx.AsyncClient(timeout=15.0)
_HOP_BY_HOP = {"host", "content-length", "connection", "transfer-encoding", "keep-alive"}
_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"]


@router.get("/api/_routes", tags=["gateway"])
def list_routes() -> dict:
    return {prefix: service_url(service) for prefix, service in ROUTES.items()}


@router.get("/health/all", tags=["gateway"])
async def health_all() -> dict:
    result = {}
    for service in sorted(set(ROUTES.values())):
        try:
            response = await _client.get(f"{service_url(service)}/health", timeout=2.0)
            result[service] = response.json().get("status", "unknown")
        except httpx.HTTPError:
            result[service] = "down"
    return result


async def _forward(prefix: str, path: str, request: Request) -> Response:
    service = ROUTES.get(prefix)
    if service is None:
        raise NotFound(f"no route for /api/{prefix}")
    upstream_path = f"{PATH_REWRITES[prefix]}/{path}".rstrip("/") or "/"
    headers = {k: v for k, v in request.headers.items() if k.lower() not in _HOP_BY_HOP}
    headers.setdefault("x-request-id", str(uuid.uuid4()))
    try:
        upstream = await _client.request(
            request.method,
            f"{service_url(service)}{upstream_path}",
            params=request.query_params,
            content=await request.body(),
            headers=headers,
        )
    except httpx.TransportError as exc:
        raise DownstreamUnavailable(service, str(exc)) from exc
    return Response(
        content=upstream.content,
        status_code=upstream.status_code,
        media_type=upstream.headers.get("content-type"),
        headers={"x-request-id": headers["x-request-id"], "x-upstream-service": service},
    )


@router.api_route("/api/{prefix}", methods=_METHODS, include_in_schema=False)
async def proxy_root(prefix: str, request: Request) -> Response:
    return await _forward(prefix, "", request)


@router.api_route("/api/{prefix}/{path:path}", methods=_METHODS, include_in_schema=False)
async def proxy(prefix: str, path: str, request: Request) -> Response:
    return await _forward(prefix, path, request)
