"""Public route table: /api/<prefix>/... -> backend service."""
ROUTES: dict[str, str] = {
    "catalog": "catalog",
    "warehouses": "warehouse",
    "inventory": "inventory",
    "orders": "sales-order",
    "purchasing": "purchasing",
    "notifications": "notification",
    "events": "event-bus",
}

# Gateway prefix -> path prefix on the backend service.
PATH_REWRITES: dict[str, str] = {
    "catalog": "",
    "warehouses": "/warehouses",
    "inventory": "",
    "orders": "/orders",
    "purchasing": "",
    "notifications": "/notifications",
    "events": "",
}
