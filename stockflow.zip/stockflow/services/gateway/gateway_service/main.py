"""API gateway: single public entry point."""
from stockflow_common.app_factory import create_service_app

from .proxy import router

app = create_service_app("gateway", description="Routes /api/<prefix>/... to StockFlow backend services.")
app.include_router(router)
