from gateway_service.routes import PATH_REWRITES, ROUTES
from stockflow_common.settings import load_registry


def test_every_route_targets_a_registered_service():
    services = set(load_registry()["services"])
    assert set(ROUTES.values()) <= services


def test_every_route_has_a_rewrite_rule():
    assert set(ROUTES) == set(PATH_REWRITES)


def test_routes_endpoint_lists_prefixes():
    from fastapi.testclient import TestClient

    from gateway_service.main import app

    with TestClient(app) as client:
        body = client.get("/api/_routes").json()
    assert body["orders"].endswith(":8004")


def test_unknown_prefix_is_404():
    from fastapi.testclient import TestClient

    from gateway_service.main import app

    with TestClient(app) as client:
        assert client.get("/api/unknown/thing").status_code == 404
