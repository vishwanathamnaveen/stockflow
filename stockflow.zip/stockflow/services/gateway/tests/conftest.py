import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "libs" / "common"), str(ROOT / "services" / "gateway")]

from stockflow_common.testing import prepare_test_environment  # noqa: E402

prepare_test_environment("gateway")
