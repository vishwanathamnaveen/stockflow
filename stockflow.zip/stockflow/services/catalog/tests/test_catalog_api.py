import json

from catalog_service.models import Outbox

PRODUCT = {
    "sku": "DRL-1001",
    "name": "Cordless Drill",
    "category": "power-tools",
    "unit_price_cents": 649900,
    "standard_cost_cents": 412000,
    "reorder_point": 10,
    "reorder_qty": 40,
    "preferred_supplier_code": "SUP-ACME",
}


def test_create_and_get_product(client):
    assert client.post("/products", json=PRODUCT).status_code == 201
    body = client.get("/products/DRL-1001").json()
    assert body["name"] == "Cordless Drill"
    assert body["active"] is True


def test_duplicate_sku_is_conflict(client):
    client.post("/products", json=PRODUCT)
    response = client.post("/products", json=PRODUCT)
    assert response.status_code == 409
    assert response.json()["error"] == "conflict"


def test_invalid_sku_format_rejected(client):
    assert client.post("/products", json={**PRODUCT, "sku": "bad sku"}).status_code == 422


def test_reorder_policy_endpoint(client):
    client.post("/products", json=PRODUCT)
    policy = client.get("/products/DRL-1001/reorder-policy").json()
    assert policy == {
        "sku": "DRL-1001",
        "reorder_point": 10,
        "reorder_qty": 40,
        "preferred_supplier_code": "SUP-ACME",
        "standard_cost_cents": 412000,
    }


def test_policy_change_publishes_product_updated_with_flag(client, session):
    client.post("/products", json=PRODUCT)
    client.patch("/products/DRL-1001", json={"reorder_point": 25})
    client.patch("/products/DRL-1001", json={"name": "Drill 18V"})
    events = [json.loads(row.payload) for row in session.query(Outbox).filter_by(topic="product.updated").order_by(Outbox.id)]
    assert events[0]["policy_changed"] is True
    assert events[1]["policy_changed"] is False


def test_filter_by_category(client):
    client.post("/products", json=PRODUCT)
    client.post("/products", json={**PRODUCT, "sku": "BOX-4001", "category": "packaging"})
    assert [p["sku"] for p in client.get("/products", params={"category": "packaging"}).json()] == ["BOX-4001"]
