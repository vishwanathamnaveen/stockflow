from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ProductCreate(BaseModel):
    sku: str = Field(min_length=3, max_length=40, pattern=r"^[A-Z0-9-]+$")
    name: str = Field(min_length=1, max_length=200)
    description: str = ""
    category: str
    unit_price_cents: int = Field(gt=0)
    standard_cost_cents: int = Field(gt=0)
    reorder_point: int = Field(default=10, ge=0)
    reorder_qty: int = Field(default=50, gt=0)
    preferred_supplier_code: str | None = None


class ProductUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    category: str | None = None
    unit_price_cents: int | None = Field(default=None, gt=0)
    standard_cost_cents: int | None = Field(default=None, gt=0)
    reorder_point: int | None = Field(default=None, ge=0)
    reorder_qty: int | None = Field(default=None, gt=0)
    preferred_supplier_code: str | None = None
    active: bool | None = None


class ProductOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    sku: str
    name: str
    description: str
    category: str
    unit_price_cents: int
    standard_cost_cents: int
    reorder_point: int
    reorder_qty: int
    preferred_supplier_code: str | None
    active: bool
    created_at: datetime
    updated_at: datetime


class ReorderPolicy(BaseModel):
    sku: str
    reorder_point: int
    reorder_qty: int
    preferred_supplier_code: str | None
    standard_cost_cents: int
