from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from . import domain
from .database import db
from .schemas import ProductCreate, ProductOut, ProductUpdate, ReorderPolicy

router = APIRouter(prefix="/products", tags=["products"])


@router.post("", response_model=ProductOut, status_code=201)
def create_product(data: ProductCreate, session: Session = Depends(db.session)):
    return domain.create_product(session, data)


@router.get("", response_model=list[ProductOut])
def list_products(category: str | None = None, active: bool | None = None, session: Session = Depends(db.session)):
    return domain.list_products(session, category, active)


@router.get("/{sku}", response_model=ProductOut)
def get_product(sku: str, session: Session = Depends(db.session)):
    return domain.get_product(session, sku)


@router.patch("/{sku}", response_model=ProductOut)
def update_product(sku: str, data: ProductUpdate, session: Session = Depends(db.session)):
    return domain.update_product(session, sku, data)


@router.get("/{sku}/reorder-policy", response_model=ReorderPolicy)
def reorder_policy(sku: str, session: Session = Depends(db.session)):
    product = domain.get_product(session, sku)
    return ReorderPolicy(
        sku=product.sku,
        reorder_point=product.reorder_point,
        reorder_qty=product.reorder_qty,
        preferred_supplier_code=product.preferred_supplier_code,
        standard_cost_cents=product.standard_cost_cents,
    )
