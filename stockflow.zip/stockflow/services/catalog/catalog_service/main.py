"""Catalog service: products, prices and reorder policies."""
from stockflow_common.app_factory import create_service_app
from stockflow_common.events import OutboxRelay

from .api import router
from .database import db
from .models import Base, Outbox

relay = OutboxRelay(db.SessionLocal, Outbox, source="catalog")

app = create_service_app(
    "catalog",
    description="Product catalogue: SKUs, prices, standard cost and reorder policy.",
    on_startup=[lambda: db.create_all(Base), relay.start],
    on_shutdown=[relay.stop],
)
app.include_router(router)
