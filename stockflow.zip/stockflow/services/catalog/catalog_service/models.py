from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from stockflow_common.events import OutboxMixin, utcnow


class Base(DeclarativeBase):
    pass


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sku: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(80), index=True)
    unit_price_cents: Mapped[int] = mapped_column(Integer)
    standard_cost_cents: Mapped[int] = mapped_column(Integer)
    reorder_point: Mapped[int] = mapped_column(Integer, default=10)
    reorder_qty: Mapped[int] = mapped_column(Integer, default=50)
    # Supplier codes are owned by the purchasing service (cross-service reference, no FK).
    preferred_supplier_code: Mapped[str | None] = mapped_column(String(40), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Outbox(OutboxMixin, Base):
    __tablename__ = "outbox"
