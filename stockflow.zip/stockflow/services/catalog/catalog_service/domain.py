"""Catalog business logic. See docs/business-rules.md (BR-001, BR-002)."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from stockflow_common.errors import Conflict, NotFound
from stockflow_common.events import publish_event

from .models import Outbox, Product
from .schemas import ProductCreate, ProductUpdate

SOURCE = "catalog"
POLICY_FIELDS = {"reorder_point", "reorder_qty", "preferred_supplier_code", "standard_cost_cents", "active"}


def get_product(session: Session, sku: str) -> Product:
    product = session.scalar(select(Product).where(Product.sku == sku))
    if product is None:
        raise NotFound(f"product {sku} not found", details={"sku": sku})
    return product


def list_products(session: Session, category: str | None = None, active: bool | None = None) -> list[Product]:
    query = select(Product).order_by(Product.sku)
    if category:
        query = query.where(Product.category == category)
    if active is not None:
        query = query.where(Product.active == active)
    return list(session.scalars(query))


def create_product(session: Session, data: ProductCreate) -> Product:
    if session.scalar(select(Product).where(Product.sku == data.sku)) is not None:
        raise Conflict(f"sku {data.sku} already exists", details={"sku": data.sku})
    product = Product(**data.model_dump())
    session.add(product)
    publish_event(session, Outbox, topic="product.created", payload=data.model_dump(), source=SOURCE)
    session.commit()
    return product


def update_product(session: Session, sku: str, data: ProductUpdate) -> Product:
    product = get_product(session, sku)
    changes = data.model_dump(exclude_unset=True)
    for field, value in changes.items():
        setattr(product, field, value)
    if changes:
        publish_event(
            session,
            Outbox,
            topic="product.updated",
            payload={"sku": sku, "changed_fields": sorted(changes), "policy_changed": bool(POLICY_FIELDS & set(changes))},
            source=SOURCE,
        )
    session.commit()
    return product
