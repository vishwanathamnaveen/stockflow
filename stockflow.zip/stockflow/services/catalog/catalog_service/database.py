from stockflow_common.db import Database
from stockflow_common.settings import ServiceSettings

settings = ServiceSettings.for_service("catalog")
db = Database(settings.database_url)
