# StockFlow demo guide (presenter notes)

> **Exclude this file from knowledge-graph ingestion.** It contains the
> answers (seeded conflicts, latent defects, expected impact sets). Add
> `DEMO_GUIDE.md` to your onboarding ignore list.

## 1. Run it

```bash
pip install -r requirements-dev.txt
python scripts/run_local.py --reset          # terminal 1
python scripts/seed_data.py                  # terminal 2
python scripts/generate_traffic.py --orders 150
python scripts/run_tests.py                  # writes var/quality/*
```

Runtime output lands in `var/`: `data/` (SQLite per service), `logs/`,
`traces/` (one JSONL file per service), `quality/` (JUnit + per-test coverage).

## 2. Where each graph gets its evidence

| Graph | Sources in this repo | Notes |
|---|---|---|
| Code | `services/*/<package>/`, `libs/common/stockflow_common/` | Unique package names per service; shared lib creates fan-out edges. |
| Service | `config/services.yaml`, each service's `clients.py` (REST), `contracts/openapi/*.json`, `contracts/events.yaml`, `config/subscriptions.yaml`, `services/gateway/gateway_service/routes.py` | REST edges: static from `ServiceClient("<service>")`. Event edges: `publish_event(topic=...)` + subscriptions. |
| Data | `models.py` per service; cross-service string references (`sku`, `supplier_code`, `warehouse_code`) | No cross-service FKs by design (ADR-001). |
| Configuration | `config/services.yaml`, `config/flags.json`, env vars read via `env_int/env_float/env_bool/os.environ` | Flags are read by `is_enabled()` / `flag_value()` calls. |
| Runtime | `var/traces/*.jsonl`, `var/logs/*.log` | Spans have `peer.service` on client calls and `messaging.*` on publish/process. One trace crosses gateway → sales-order → catalog/inventory → event-bus → purchasing/notification. |
| Quality | `services/*/tests/`, `var/quality/<suite>-coverage.json` (per-test contexts), `var/quality/<suite>-junit.xml` | Coverage JSON maps each line to the tests that executed it. |
| History | `git log` (23 commits, 5 authors), `.github/CODEOWNERS` | Includes a bug fix, a revert, a cross-service co-change and an ADR-driven change. |
| Knowledge | `docs/architecture.md`, `docs/business-rules.md` (BR-xxx → code), `docs/adr/`, `docs/runbooks/`, `README.md` | Business rules are also cited in module docstrings. |

## 3. Seeded ground truth

**Conflict (CONFLICTING state).** `README.md` says reservation calls are
retried **3** times. `ADR-003` and `sales_order_service/config.py` say **2**.
The ADR superseded the README in commit "feat(sales-order): reduce reservation
retries to 2"; the README was never updated. Expected behaviour: the system
flags the conflict and treats ADR + code as authoritative (or escalates).

**Latent defect 1: ghost reservations.** If inventory is slow, sales-order
times out, retries, then rejects the order with `inventory_unavailable`, but
the slow reservation still completes. Stock stays reserved for a rejected
order. Reproduce: enable `inventory_reservation_delay_ms` in
`config/flags.json`, place an order, then `GET /api/inventory/reservations/<order>`.

**Latent defect 2: non-atomic event handling.** In inventory,
`on_purchase_order_received` calls `domain.receive_stock`, which commits;
the inbox row is written in a second commit. A crash between the two would
apply the receipt twice on redelivery.

**Declared but unconsumed events.** `product.created`, `stock.reserved` and
`stock.released` are published but have no subscribers. The static graph
shows producers; runtime shows events stored with zero deliveries.

**Field-level contract trap.** `stock.low` has two consumers. `notification`
reads `available` and `reorder_point`; `purchasing` reads only `sku`.

## 4. Demo tasks with expected impact

Use these as live tasks and as evaluation cases (compare predicted impact with
this list).

| Task | Risk | Expected impact |
|---|---|---|
| T1: Show supplier lead time in the purchase-order email | Low | `notification_service/handlers.py` (`on_purchase_order_submitted`), `notification_service/clients.py` (needs `lead_time_days` from purchasing `GET /suppliers/{code}`), `tests/test_notification_handlers.py`. No contract change. |
| T2: Rename `stock.low` field `available` → `available_qty` | Medium–High | Producer: `inventory_service/domain.py::check_low_stock`, inventory tests. Consumer: `notification_service/handlers.py::on_stock_low` + tests. Contract: `contracts/events.yaml`. **Not** purchasing (reads only `sku`). Tests to run: inventory low-stock tests, notification stock.low test, e2e. |
| T3: Fix ghost reservations | High | `sales_order_service/domain.py::place_order` (release on `inventory_unavailable`) and/or inventory reservation expiry; `sales_order_service/clients.py`; ADR-003 (amend); `docs/runbooks/stock-discrepancy.md`; sales-order + inventory tests; e2e. Cross-service, touches order lifecycle and stock correctness. |
| T4: Change the retry count to 1 | Medium | `sales_order_service/config.py`, ADR-003, retry-policy tests, README conflict. Good to show the CONFLICTING evidence state. |
| T5: Change `ServiceClient` retry backoff to exponential | High (blast radius) | `libs/common/stockflow_common/http_client.py`; every service's `clients.py` depends on it (inventory, sales-order, purchasing, notification); common http-client tests; ADR-003 describes linear backoff. |

## 5. Runtime scenarios (flip flags while running)

| Flag | What the audience sees |
|---|---|
| `inventory_reservation_delay_ms` | sales-order logs `retrying POST /reservations` twice, order rejected after ~7 s, ghost reservation left behind. |
| `notification_failure` | event-bus retries with exponential backoff; after 5 attempts `GET /api/events/deliveries?status=DEAD` shows dead letters; `POST .../redeliver` recovers after turning the flag off. |
| `auto_reorder` off | `stock.low` still delivered to purchasing, but no PO is created. |
| `auto_submit_reorders` on | Auto POs go straight to SUBMITTED; notification emails the supplier (notification → purchasing REST call appears in traces). |

## 6. History highlights (for the history graph and PR replay)

- `fix(inventory): allocation ignored reserved stock (INC-027)` — bug fix with a regression test.
- `perf(inventory): cache stock summaries in-process` then its **revert** (INC-029).
- `feat(sales-order): reduce reservation retries to 2 (ADR-003, INC-031)` — code + ADR, README left stale.
- `feat(catalog): announce policy changes ...` — co-change across catalog, inventory, config and contracts.
- `fix(event-bus): exponential backoff for failed deliveries`.

Replay each of these as an evaluation case: check out the parent commit, give
the commit message as the task, compare predicted impact with the files the
commit actually changed.
